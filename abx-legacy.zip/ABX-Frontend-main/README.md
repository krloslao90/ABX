# ABX Frontend 

## Dependencies Install

npm install --legacy-peer-deps

# ABX Project Information

## Tech Stack

This project follows a **hybrid Firebase + GCP architecture**, leveraging Firebase for **ease of use** and GCP for **scalability**.

| **Component** | **Technology** | **Enhancements** |
|--------------|--------------|----------------|
| **Frontend (Next.js)** | [Firebase Hosting](https://firebase.google.com/docs/hosting) | Fast, global CDN, easy deploys. |
| **Backend (API - NestJS)** | [GCP Cloud Run](https://cloud.google.com/run) | Fully managed, auto-scaling backend, supports Prisma & multi-tenancy. |
| **Database** | [GCP Cloud SQL (PostgreSQL + Prisma)](https://cloud.google.com/sql/docs/postgres) | **Row-Based Multi-Tenancy, Role-Level Security (RLS).** |
| **Auth** | [Firebase Auth](https://firebase.google.com/docs/auth) | **Custom Claims for RBAC (Role-Based Access Control).** |
| **File Storage** | [Firebase Storage (GCP Cloud Storage)](https://firebase.google.com/docs/storage) | Same as AWS S3, fully integrated with GCP. |
| **Real-Time Features** | [Firestore + Pub/Sub](https://firebase.google.com/docs/firestore) | **Firestore for real-time sync, Pub/Sub for async processing.** |
| **Payments** | [Stripe](https://stripe.com) (via Cloud Run) | Best for SaaS billing, supports multi-tenant invoicing. |
| **Deployment** | [Cloud Build](https://cloud.google.com/build) + [GitHub Actions](https://github.com/features/actions) | **Automated CI/CD pipeline.** |
| **Monitoring** | [Firebase Performance](https://firebase.google.com/docs/perf-mon) + [Cloud Logging](https://cloud.google.com/logging) | **Added Sentry for better error tracking.** |
| **Background Jobs** | [Cloud Tasks](https://cloud.google.com/tasks/docs/overview) | **For scheduled reports, email notifications, async jobs.** |
| **AI & Analytics (Future)** | [Google Vertex AI](https://cloud.google.com/vertex-ai) | **Predict therapy success, optimize therapist recommendations.** |

---

## 📌 Why This Hybrid Approach?

✅ **Fast MVP launch** with Firebase for hosting, auth, and real-time features.  
✅ **Avoids painful migrations later** by using Cloud SQL & Cloud Run from the start.  
✅ **Scalable architecture** with Cloud Run (backend) + Cloud SQL (database).  
✅ **Firestore used only for real-time updates** (avoiding NoSQL scaling issues). 