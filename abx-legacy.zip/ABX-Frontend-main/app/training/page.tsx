"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  ChevronLeft,
  Search,
  Filter,
  Play,
  CheckCircle2,
  Clock,
  AlertCircle,
  Award,
  FileText,
  Download,
} from "lucide-react"
import Link from "next/link"
import { format, addMonths } from "date-fns"

// Mock training courses
const COURSES = [
  {
    id: 1,
    title: "ABA Therapy Fundamentals",
    description: "Introduction to Applied Behavior Analysis therapy principles and techniques",
    duration: "4 hours",
    modules: 8,
    category: "Core Training",
    required: true,
  },
  {
    id: 2,
    title: "HIPAA Compliance",
    description: "Understanding HIPAA regulations and patient privacy requirements",
    duration: "2 hours",
    modules: 5,
    category: "Compliance",
    required: true,
  },
  {
    id: 3,
    title: "Crisis Management",
    description: "Techniques for managing crisis situations safely and effectively",
    duration: "3 hours",
    modules: 6,
    category: "Safety",
    required: true,
  },
  {
    id: 4,
    title: "Documentation Best Practices",
    description: "Guidelines for effective clinical documentation and record-keeping",
    duration: "2 hours",
    modules: 4,
    category: "Professional Development",
    required: true,
  },
  {
    id: 5,
    title: "Advanced Reinforcement Techniques",
    description: "Advanced strategies for implementing reinforcement in therapy sessions",
    duration: "3 hours",
    modules: 6,
    category: "Advanced Training",
    required: false,
  },
  {
    id: 6,
    title: "Parent Training Strategies",
    description: "Effective methods for training parents to implement therapy techniques",
    duration: "2.5 hours",
    modules: 5,
    category: "Professional Development",
    required: false,
  },
]

// Mock staff training records
const STAFF_TRAINING = [
  {
    id: 1,
    staff: "Dr. Sarah Miller",
    role: "Speech Therapist",
    courses: [
      {
        courseId: 1,
        status: "Completed",
        completionDate: new Date(2023, 8, 15),
        expirationDate: addMonths(new Date(2023, 8, 15), 12),
      },
      {
        courseId: 2,
        status: "Completed",
        completionDate: new Date(2023, 10, 10),
        expirationDate: addMonths(new Date(2023, 10, 10), 12),
      },
      {
        courseId: 3,
        status: "Completed",
        completionDate: new Date(2024, 0, 5),
        expirationDate: addMonths(new Date(2024, 0, 5), 12),
      },
      {
        courseId: 4,
        status: "Completed",
        completionDate: new Date(2023, 11, 20),
        expirationDate: addMonths(new Date(2023, 11, 20), 12),
      },
      { courseId: 5, status: "In Progress", progress: 75 },
      { courseId: 6, status: "Not Started" },
    ],
  },
  {
    id: 2,
    staff: "Thomas Wilson",
    role: "Behavioral Therapist",
    courses: [
      {
        courseId: 1,
        status: "Completed",
        completionDate: new Date(2023, 9, 5),
        expirationDate: addMonths(new Date(2023, 9, 5), 12),
      },
      {
        courseId: 2,
        status: "Completed",
        completionDate: new Date(2023, 9, 10),
        expirationDate: addMonths(new Date(2023, 9, 10), 12),
      },
      {
        courseId: 3,
        status: "Completed",
        completionDate: new Date(2023, 9, 15),
        expirationDate: addMonths(new Date(2023, 9, 15), 12),
      },
      { courseId: 4, status: "In Progress", progress: 50 },
      { courseId: 5, status: "In Progress", progress: 25 },
      { courseId: 6, status: "Not Started" },
    ],
  },
  {
    id: 3,
    staff: "Jessica Taylor",
    role: "Occupational Therapist",
    courses: [
      {
        courseId: 1,
        status: "Completed",
        completionDate: new Date(2023, 7, 20),
        expirationDate: addMonths(new Date(2023, 7, 20), 12),
      },
      {
        courseId: 2,
        status: "Completed",
        completionDate: new Date(2023, 7, 25),
        expirationDate: addMonths(new Date(2023, 7, 25), 12),
      },
      {
        courseId: 3,
        status: "Completed",
        completionDate: new Date(2023, 8, 5),
        expirationDate: addMonths(new Date(2023, 8, 5), 12),
      },
      {
        courseId: 4,
        status: "Completed",
        completionDate: new Date(2023, 8, 10),
        expirationDate: addMonths(new Date(2023, 8, 10), 12),
      },
      {
        courseId: 5,
        status: "Completed",
        completionDate: new Date(2024, 1, 15),
        expirationDate: addMonths(new Date(2024, 1, 15), 12),
      },
      { courseId: 6, status: "In Progress", progress: 80 },
    ],
  },
]

// Mock certifications
const CERTIFICATIONS = [
  {
    id: 1,
    staff: "Dr. Sarah Miller",
    certifications: [
      {
        name: "CCC-SLP",
        description: "Certificate of Clinical Competence in Speech-Language Pathology",
        issuer: "ASHA",
        issueDate: new Date(2020, 5, 15),
        expirationDate: new Date(2025, 5, 15),
        status: "Active",
      },
      {
        name: "BCBA",
        description: "Board Certified Behavior Analyst",
        issuer: "BACB",
        issueDate: new Date(2021, 3, 10),
        expirationDate: new Date(2025, 3, 10),
        status: "Active",
      },
    ],
  },
  {
    id: 2,
    staff: "Thomas Wilson",
    certifications: [
      {
        name: "RBT",
        description: "Registered Behavior Technician",
        issuer: "BACB",
        issueDate: new Date(2022, 1, 20),
        expirationDate: new Date(2024, 1, 20),
        status: "Expiring Soon",
      },
      {
        name: "CPR/First Aid",
        description: "CPR and First Aid Certification",
        issuer: "American Red Cross",
        issueDate: new Date(2023, 8, 5),
        expirationDate: new Date(2025, 8, 5),
        status: "Active",
      },
    ],
  },
  {
    id: 3,
    staff: "Jessica Taylor",
    certifications: [
      {
        name: "OTR/L",
        description: "Occupational Therapist, Registered/Licensed",
        issuer: "NBCOT",
        issueDate: new Date(2019, 4, 10),
        expirationDate: new Date(2024, 4, 10),
        status: "Active",
      },
      {
        name: "SWC",
        description: "Sensory Integration and Processing Certification",
        issuer: "SIPT",
        issueDate: new Date(2021, 7, 15),
        expirationDate: new Date(2024, 7, 15),
        status: "Active",
      },
      {
        name: "CPR/First Aid",
        description: "CPR and First Aid Certification",
        issuer: "American Red Cross",
        issueDate: new Date(2023, 2, 20),
        expirationDate: new Date(2025, 2, 20),
        status: "Active",
      },
    ],
  },
]

export default function TrainingPage() {
  const [activeTab, setActiveTab] = useState("courses")

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Training & Certifications</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="courses" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="courses">Training Courses</TabsTrigger>
            <TabsTrigger value="staff">Staff Training</TabsTrigger>
            <TabsTrigger value="certifications">Certifications</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          {/* Training Courses Tab */}
          <TabsContent value="courses">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {COURSES.map((course) => (
                <Card key={course.id} className="flex flex-col">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle>{course.title}</CardTitle>
                      {course.required && (
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          Required
                        </Badge>
                      )}
                    </div>
                    <CardDescription>{course.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Duration:</span>
                        <span className="text-sm">{course.duration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Modules:</span>
                        <span className="text-sm">{course.modules}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Category:</span>
                        <span className="text-sm">{course.category}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">
                      <Play className="mr-2 h-4 w-4" />
                      Start Course
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Staff Training Tab */}
          <TabsContent value="staff">
            <Card>
              <CardHeader>
                <CardTitle>Staff Training Status</CardTitle>
                <CardDescription>Track training completion and requirements for all staff</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Staff Member</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Required Courses</TableHead>
                      <TableHead>Completion Rate</TableHead>
                      <TableHead>Upcoming Renewals</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {STAFF_TRAINING.map((staff) => {
                      // Calculate completion rate for required courses
                      const requiredCourseIds = COURSES.filter((c) => c.required).map((c) => c.id)
                      const requiredCourses = staff.courses.filter((c) => requiredCourseIds.includes(c.courseId))
                      const completedRequired = requiredCourses.filter((c) => c.status === "Completed").length
                      const completionRate = Math.round((completedRequired / requiredCourseIds.length) * 100)

                      // Find upcoming renewals
                      const upcomingRenewals = staff.courses
                        .filter((c) => c.status === "Completed" && c.expirationDate)
                        .filter((c) => {
                          const monthsUntilExpiration = Math.round(
                            (c.expirationDate.getTime() - new Date().getTime()) / (30 * 24 * 60 * 60 * 1000),
                          )
                          return monthsUntilExpiration <= 3
                        })

                      return (
                        <TableRow key={staff.id}>
                          <TableCell className="font-medium">{staff.staff}</TableCell>
                          <TableCell>{staff.role}</TableCell>
                          <TableCell>{`${completedRequired}/${requiredCourseIds.length} Completed`}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={completionRate} className="h-2 w-[100px]" />
                              <span className="text-sm">{completionRate}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {upcomingRenewals.length > 0 ? (
                              <Badge variant="secondary" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                                {upcomingRenewals.length} course(s) expiring soon
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                No upcoming renewals
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              View Details
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Training Compliance Overview</CardTitle>
                  <CardDescription>Summary of staff training compliance status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Overall Compliance</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">92%</div>
                        <div className="mt-2">
                          <Progress value={92} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Expiring Certifications</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">1</div>
                        <p className="text-xs text-muted-foreground">Within next 30 days</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Overdue Training</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">0</div>
                        <p className="text-xs text-muted-foreground">All staff up to date</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Certifications Tab */}
          <TabsContent value="certifications">
            <Card>
              <CardHeader>
                <CardTitle>Staff Certifications</CardTitle>
                <CardDescription>Track professional certifications and licenses</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Staff Member</TableHead>
                      <TableHead>Certification</TableHead>
                      <TableHead>Issuing Organization</TableHead>
                      <TableHead>Issue Date</TableHead>
                      <TableHead>Expiration Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {CERTIFICATIONS.flatMap((staff) =>
                      staff.certifications.map((cert, index) => (
                        <TableRow key={`${staff.id}-${index}`}>
                          <TableCell className="font-medium">{staff.staff}</TableCell>
                          <TableCell>
                            <div>
                              <p>{cert.name}</p>
                              <p className="text-xs text-muted-foreground">{cert.description}</p>
                            </div>
                          </TableCell>
                          <TableCell>{cert.issuer}</TableCell>
                          <TableCell>{format(cert.issueDate, "MMM d, yyyy")}</TableCell>
                          <TableCell>{format(cert.expirationDate, "MMM d, yyyy")}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                cert.status === "Active"
                                  ? "outline"
                                  : cert.status === "Expiring Soon"
                                    ? "secondary"
                                    : "destructive"
                              }
                              className={
                                cert.status === "Active"
                                  ? "bg-green-50 text-green-700 border-green-200"
                                  : cert.status === "Expiring Soon"
                                    ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                    : "bg-red-50 text-red-700 border-red-200"
                              }
                            >
                              <div className="flex items-center gap-1">
                                {cert.status === "Active" && <CheckCircle2 className="h-3.5 w-3.5" />}
                                {cert.status === "Expiring Soon" && <Clock className="h-3.5 w-3.5" />}
                                {cert.status === "Expired" && <AlertCircle className="h-3.5 w-3.5" />}
                                <span>{cert.status}</span>
                              </div>
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </TableCell>
                        </TableRow>
                      )),
                    )}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="ml-auto">
                  <Award className="mr-2 h-4 w-4" />
                  Add Certification
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Training & Certification Reports</CardTitle>
                <CardDescription>Generate and download compliance reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Staff Training Compliance Report</h3>
                        <p className="text-sm text-muted-foreground">
                          Detailed report of all staff training completion status
                        </p>
                      </div>
                      <Button variant="outline">
                        <Download className="mr-2 h-4 w-4" />
                        Generate
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Certification Expiration Report</h3>
                        <p className="text-sm text-muted-foreground">Report of upcoming certification expirations</p>
                      </div>
                      <Button variant="outline">
                        <Download className="mr-2 h-4 w-4" />
                        Generate
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Training Completion Certificates</h3>
                        <p className="text-sm text-muted-foreground">
                          Generate certificates for completed training courses
                        </p>
                      </div>
                      <Button variant="outline">
                        <Download className="mr-2 h-4 w-4" />
                        Generate
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Annual Training Summary</h3>
                        <p className="text-sm text-muted-foreground">
                          Annual summary of all training activities and compliance
                        </p>
                      </div>
                      <Button variant="outline">
                        <Download className="mr-2 h-4 w-4" />
                        Generate
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

