"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ChevronLeft, Download, FileText, Calendar, BarChart3, PieChart, LineChart, Users } from "lucide-react"
import Link from "next/link"

export default function ReportsPage() {
  const [reportType, setReportType] = useState("client-progress")
  const [timeframe, setTimeframe] = useState("month")

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Reports</h2>
          <div className="ml-auto flex items-center gap-2">
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[180px]">
                <Calendar className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Last 7 days</SelectItem>
                <SelectItem value="month">Last 30 days</SelectItem>
                <SelectItem value="quarter">Last 90 days</SelectItem>
                <SelectItem value="year">Last 12 months</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <Tabs defaultValue="standard" className="mb-6">
          <TabsList>
            <TabsTrigger value="standard">Standard Reports</TabsTrigger>
            <TabsTrigger value="custom">Custom Reports</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled Reports</TabsTrigger>
          </TabsList>

          {/* Standard Reports Tab */}
          <TabsContent value="standard">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card
                className={`cursor-pointer hover:bg-muted/50 ${reportType === "client-progress" ? "border-primary" : ""}`}
                onClick={() => setReportType("client-progress")}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Client Progress</CardTitle>
                  <LineChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Track progress across treatment goals for all clients</p>
                </CardContent>
              </Card>
              <Card
                className={`cursor-pointer hover:bg-muted/50 ${reportType === "session-analysis" ? "border-primary" : ""}`}
                onClick={() => setReportType("session-analysis")}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Session Analysis</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Analyze session data, attendance, and outcomes</p>
                </CardContent>
              </Card>
              <Card
                className={`cursor-pointer hover:bg-muted/50 ${reportType === "billing-summary" ? "border-primary" : ""}`}
                onClick={() => setReportType("billing-summary")}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Billing Summary</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Financial reports for billing and insurance claims</p>
                </CardContent>
              </Card>
              <Card
                className={`cursor-pointer hover:bg-muted/50 ${reportType === "staff-productivity" ? "border-primary" : ""}`}
                onClick={() => setReportType("staff-productivity")}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Staff Productivity</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Analyze therapist workload, efficiency, and outcomes</p>
                </CardContent>
              </Card>
              <Card
                className={`cursor-pointer hover:bg-muted/50 ${reportType === "therapy-distribution" ? "border-primary" : ""}`}
                onClick={() => setReportType("therapy-distribution")}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Therapy Distribution</CardTitle>
                  <PieChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Breakdown of therapy types and service distribution</p>
                </CardContent>
              </Card>
              <Card
                className={`cursor-pointer hover:bg-muted/50 ${reportType === "compliance" ? "border-primary" : ""}`}
                onClick={() => setReportType("compliance")}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Compliance Reports</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">HIPAA compliance and audit reports</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>
                  {reportType === "client-progress" && "Client Progress Report"}
                  {reportType === "session-analysis" && "Session Analysis Report"}
                  {reportType === "billing-summary" && "Billing Summary Report"}
                  {reportType === "staff-productivity" && "Staff Productivity Report"}
                  {reportType === "therapy-distribution" && "Therapy Distribution Report"}
                  {reportType === "compliance" && "Compliance Report"}
                </CardTitle>
                <CardDescription>
                  {reportType === "client-progress" && "Tracking progress across treatment goals for all clients"}
                  {reportType === "session-analysis" && "Analysis of session data, attendance, and outcomes"}
                  {reportType === "billing-summary" && "Financial summary for billing and insurance claims"}
                  {reportType === "staff-productivity" && "Analysis of therapist workload, efficiency, and outcomes"}
                  {reportType === "therapy-distribution" && "Breakdown of therapy types and service distribution"}
                  {reportType === "compliance" && "HIPAA compliance and audit reports"}
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[400px] flex items-center justify-center">
                <div className="text-center">
                  <FileText className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Report Preview</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    Select parameters and generate the report to view data
                  </p>
                  <Button>Generate Report</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Custom Reports Tab */}
          <TabsContent value="custom">
            <Card>
              <CardHeader>
                <CardTitle>Custom Report Builder</CardTitle>
                <CardDescription>Create customized reports with specific metrics and parameters</CardDescription>
              </CardHeader>
              <CardContent className="h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Custom Report Builder</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    This feature is coming soon. You'll be able to create fully customized reports.
                  </p>
                  <Button disabled>Coming Soon</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Scheduled Reports Tab */}
          <TabsContent value="scheduled">
            <Card>
              <CardHeader>
                <CardTitle>Scheduled Reports</CardTitle>
                <CardDescription>Set up automated reports to be generated and delivered on a schedule</CardDescription>
              </CardHeader>
              <CardContent className="h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <Calendar className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Scheduled Reports</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    This feature is coming soon. You'll be able to schedule automated reports.
                  </p>
                  <Button disabled>Coming Soon</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

