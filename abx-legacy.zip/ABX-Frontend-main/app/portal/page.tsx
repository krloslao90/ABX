"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Calendar, FileText, MessageSquare, CreditCard, Download, CheckCircle2, Clock } from "lucide-react"
import Link from "next/link"

export default function ParentPortalPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
              <span className="text-lg font-bold text-primary-foreground">ABX</span>
            </div>
            <h1 className="text-xl font-bold">Parent Portal</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              Help
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Sarah Johnson" />
              <AvatarFallback>SJ</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex flex-col md:flex-row items-start gap-6 mb-6">
          <Card className="w-full md:w-1/3">
            <CardHeader className="pb-2">
              <CardTitle>Alex Johnson</CardTitle>
              <CardDescription>Client Profile</CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="flex flex-col items-center mb-6">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Alex Johnson" />
                  <AvatarFallback>AJ</AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-bold">Alex Johnson</h3>
                <p className="text-sm text-muted-foreground">Age: 6 • DOB: 03/15/2019</p>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium">Primary Therapist</p>
                  <p className="text-sm">Dr. Sarah Miller</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Therapy Type</p>
                  <p className="text-sm">Speech Therapy, Behavioral Therapy</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Next Session</p>
                  <p className="text-sm">Tomorrow, 9:00 AM</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Insurance</p>
                  <p className="text-sm">Blue Cross Blue Shield</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center border-t pt-4">
              <Button variant="outline" className="w-full" asChild>
                <Link href="/portal/profile">View Full Profile</Link>
              </Button>
            </CardFooter>
          </Card>

          <div className="w-full md:w-2/3 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button variant="outline" className="h-auto flex flex-col items-center justify-center p-4 gap-2">
                    <Calendar className="h-6 w-6" />
                    <span>Schedule</span>
                  </Button>
                  <Button variant="outline" className="h-auto flex flex-col items-center justify-center p-4 gap-2">
                    <MessageSquare className="h-6 w-6" />
                    <span>Message</span>
                  </Button>
                  <Button variant="outline" className="h-auto flex flex-col items-center justify-center p-4 gap-2">
                    <CreditCard className="h-6 w-6" />
                    <span>Billing</span>
                  </Button>
                  <Button variant="outline" className="h-auto flex flex-col items-center justify-center p-4 gap-2">
                    <FileText className="h-6 w-6" />
                    <span>Documents</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Recent Progress</CardTitle>
                <CardDescription>Latest updates on treatment goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">Increase verbal requests for preferred items</p>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">65%</span>
                        <Clock className="h-4 w-4 text-amber-500" />
                      </div>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">Follow 2-step instructions</p>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">80%</span>
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      </div>
                    </div>
                    <Progress value={80} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">Engage in cooperative play with peers</p>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">40%</span>
                        <Clock className="h-4 w-4 text-amber-500" />
                      </div>
                    </div>
                    <Progress value={40} className="h-2" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center border-t pt-4">
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/portal/progress">View All Goals</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="sessions">Sessions</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Sessions</CardTitle>
                  <CardDescription>Next scheduled therapy sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-md border bg-muted">
                        <span className="text-sm font-medium">Mar 16</span>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Speech Therapy</p>
                        <p className="text-sm text-muted-foreground">9:00 AM - 10:00 AM • Dr. Sarah Miller</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Details
                      </Button>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-md border bg-muted">
                        <span className="text-sm font-medium">Mar 18</span>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Behavioral Therapy</p>
                        <p className="text-sm text-muted-foreground">10:30 AM - 11:30 AM • Thomas Wilson</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Details
                      </Button>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-md border bg-muted">
                        <span className="text-sm font-medium">Mar 23</span>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">Speech Therapy</p>
                        <p className="text-sm text-muted-foreground">9:00 AM - 10:00 AM • Dr. Sarah Miller</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-center border-t pt-4">
                  <Button variant="outline" className="w-full">
                    View Calendar
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest updates and communications</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="relative mt-1">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full border bg-muted">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium">Session Notes Added</p>
                          <span className="text-xs text-muted-foreground">Today</span>
                        </div>
                        <p className="text-sm">Dr. Sarah Miller added notes from today's speech therapy session.</p>
                        <Button variant="link" size="sm" className="h-auto p-0">
                          View Notes
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="relative mt-1">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full border bg-muted">
                          <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium">New Message</p>
                          <span className="text-xs text-muted-foreground">Yesterday</span>
                        </div>
                        <p className="text-sm">
                          Thomas Wilson sent you a message about the upcoming behavioral therapy session.
                        </p>
                        <Button variant="link" size="sm" className="h-auto p-0">
                          Read Message
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="relative mt-1">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full border bg-muted">
                          <CreditCard className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium">Invoice Generated</p>
                          <span className="text-xs text-muted-foreground">3 days ago</span>
                        </div>
                        <p className="text-sm">A new invoice has been generated for March services.</p>
                        <Button variant="link" size="sm" className="h-auto p-0">
                          View Invoice
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Sessions Tab */}
          <TabsContent value="sessions">
            <Card>
              <CardHeader>
                <CardTitle>Session History</CardTitle>
                <CardDescription>Record of all therapy sessions and notes</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Therapist</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>
                        <div className="font-medium">Mar 15, 2024</div>
                        <div className="text-xs text-muted-foreground">9:00 AM</div>
                      </TableCell>
                      <TableCell>Speech</TableCell>
                      <TableCell>Dr. Sarah Miller</TableCell>
                      <TableCell>60 min</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Notes
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>
                        <div className="font-medium">Mar 13, 2024</div>
                        <div className="text-xs text-muted-foreground">10:30 AM</div>
                      </TableCell>
                      <TableCell>Behavioral</TableCell>
                      <TableCell>Thomas Wilson</TableCell>
                      <TableCell>45 min</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Notes
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>
                        <div className="font-medium">Mar 8, 2024</div>
                        <div className="text-xs text-muted-foreground">9:00 AM</div>
                      </TableCell>
                      <TableCell>Speech</TableCell>
                      <TableCell>Dr. Sarah Miller</TableCell>
                      <TableCell>60 min</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Notes
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>
                        <div className="font-medium">Mar 6, 2024</div>
                        <div className="text-xs text-muted-foreground">10:30 AM</div>
                      </TableCell>
                      <TableCell>Behavioral</TableCell>
                      <TableCell>Thomas Wilson</TableCell>
                      <TableCell>45 min</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Notes
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources">
            <Card>
              <CardHeader>
                <CardTitle>Resources & Home Activities</CardTitle>
                <CardDescription>Educational materials and home practice activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Visual Communication Cards</h3>
                        <p className="text-sm text-muted-foreground">
                          Printable communication cards for daily activities
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Social Stories Collection</h3>
                        <p className="text-sm text-muted-foreground">
                          Stories to help with social situations and transitions
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Speech Practice Activities</h3>
                        <p className="text-sm text-muted-foreground">Fun games to practice articulation at home</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Visual Schedule Template</h3>
                        <p className="text-sm text-muted-foreground">Customizable daily schedule template</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing">
            <Card>
              <CardHeader>
                <CardTitle>Billing History</CardTitle>
                <CardDescription>Record of all invoices and payments</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Invoice</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Mar 15, 2024</TableCell>
                      <TableCell>INV-2024-0315</TableCell>
                      <TableCell>Speech Therapy (5 sessions)</TableCell>
                      <TableCell>$750.00</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                          Pending
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Download className="mr-2 h-4 w-4" />
                          Invoice
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Feb 15, 2024</TableCell>
                      <TableCell>INV-2024-0215</TableCell>
                      <TableCell>Speech & Behavioral Therapy (8 sessions)</TableCell>
                      <TableCell>$1,200.00</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Paid
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Download className="mr-2 h-4 w-4" />
                          Invoice
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Jan 15, 2024</TableCell>
                      <TableCell>INV-2024-0115</TableCell>
                      <TableCell>Speech & Behavioral Therapy (7 sessions)</TableCell>
                      <TableCell>$1,050.00</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Paid
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Download className="mr-2 h-4 w-4" />
                          Invoice
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents">
            <Card>
              <CardHeader>
                <CardTitle>Documents</CardTitle>
                <CardDescription>Important documents and forms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Treatment Plan</h3>
                        <p className="text-sm text-muted-foreground">Current treatment plan and goals</p>
                        <p className="text-xs text-muted-foreground">Updated: March 1, 2024</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Progress Report</h3>
                        <p className="text-sm text-muted-foreground">Quarterly progress report</p>
                        <p className="text-xs text-muted-foreground">Updated: February 15, 2024</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Consent Forms</h3>
                        <p className="text-sm text-muted-foreground">
                          Signed consent for treatment and information sharing
                        </p>
                        <p className="text-xs text-muted-foreground">Updated: September 10, 2023</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Insurance Information</h3>
                        <p className="text-sm text-muted-foreground">Insurance coverage details and authorization</p>
                        <p className="text-xs text-muted-foreground">Updated: January 5, 2024</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

