"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ChevronLeft, Search, Send, MoreVertical, Phone, Video, Paperclip } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock contacts data
const CONTACTS = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Parent",
    client: "Alex Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "online",
    lastMessage: "Thank you for the update on Alex's progress!",
    lastMessageTime: new Date(2024, 2, 15, 14, 30),
    unread: 0,
  },
  {
    id: 2,
    name: "Michael Patel",
    role: "Parent",
    client: "Maya Patel",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "offline",
    lastMessage: "Can we reschedule Maya's session for next week?",
    lastMessageTime: new Date(2024, 2, 14, 10, 15),
    unread: 2,
  },
  {
    id: 3,
    name: "Jennifer Williams",
    role: "Parent",
    client: "Ethan Williams",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "online",
    lastMessage: "I'll bring the visual supports we discussed to our next session.",
    lastMessageTime: new Date(2024, 2, 13, 16, 45),
    unread: 0,
  },
  {
    id: 4,
    name: "Carlos Garcia",
    role: "Parent",
    client: "Sophia Garcia",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "offline",
    lastMessage: "Sophia has been practicing the strategies at home.",
    lastMessageTime: new Date(2024, 2, 12, 9, 20),
    unread: 0,
  },
  {
    id: 5,
    name: "Dr. Sarah Miller",
    role: "Speech Therapist",
    client: "",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "online",
    lastMessage: "I've updated the treatment plans for our shared clients.",
    lastMessageTime: new Date(2024, 2, 15, 11, 10),
    unread: 1,
  },
  {
    id: 6,
    name: "Thomas Wilson",
    role: "Behavioral Therapist",
    client: "",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "offline",
    lastMessage: "Let's discuss the new behavior intervention strategy.",
    lastMessageTime: new Date(2024, 2, 14, 15, 30),
    unread: 0,
  },
  {
    id: 7,
    name: "Jessica Taylor",
    role: "Occupational Therapist",
    client: "",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "online",
    lastMessage: "I've shared the sensory profile assessment results.",
    lastMessageTime: new Date(2024, 2, 13, 13, 45),
    unread: 0,
  },
  {
    id: 8,
    name: "Insurance Support",
    role: "Blue Cross Blue Shield",
    client: "",
    avatar: "/placeholder.svg?height=40&width=40",
    status: "offline",
    lastMessage: "We've processed the claims for February services.",
    lastMessageTime: new Date(2024, 2, 10, 10, 0),
    unread: 0,
  },
]

// Mock messages for a conversation
const MESSAGES = [
  {
    id: 1,
    sender: 1, // Sarah Johnson
    recipient: 0, // Current user
    content: "Hi there! I wanted to check in about Alex's progress with his speech therapy.",
    timestamp: new Date(2024, 2, 15, 9, 30),
    read: true,
  },
  {
    id: 2,
    sender: 0, // Current user
    recipient: 1, // Sarah Johnson
    content:
      "Good morning Sarah! Alex is doing really well with his speech therapy. He's made significant progress with his articulation goals over the past few weeks.",
    timestamp: new Date(2024, 2, 15, 9, 45),
    read: true,
  },
  {
    id: 3,
    sender: 1, // Sarah Johnson
    recipient: 0, // Current user
    content:
      "That's wonderful to hear! We've been practicing at home with the materials you provided. He seems more confident when speaking.",
    timestamp: new Date(2024, 2, 15, 10, 0),
    read: true,
  },
  {
    id: 4,
    sender: 0, // Current user
    recipient: 1, // Sarah Johnson
    content:
      "I've definitely noticed the improvement in his confidence too. The home practice is making a big difference. In our next session, I'd like to introduce some new activities focused on conversation skills.",
    timestamp: new Date(2024, 2, 15, 10, 15),
    read: true,
  },
  {
    id: 5,
    sender: 1, // Sarah Johnson
    recipient: 0, // Current user
    content:
      "That sounds great! Is there anything specific we should work on at home to prepare for these new activities?",
    timestamp: new Date(2024, 2, 15, 10, 30),
    read: true,
  },
  {
    id: 6,
    sender: 0, // Current user
    recipient: 1, // Sarah Johnson
    content:
      "Yes, I'll send you some conversation starters and turn-taking activities that you can practice during family meals or game time. These will help Alex get comfortable with the back-and-forth nature of conversation.",
    timestamp: new Date(2024, 2, 15, 10, 45),
    read: true,
  },
  {
    id: 7,
    sender: 1, // Sarah Johnson
    recipient: 0, // Current user
    content:
      "Perfect! We'll start incorporating those into our routine. Also, I wanted to ask if our Thursday session next week could be moved to Friday? We have a doctor's appointment on Thursday morning.",
    timestamp: new Date(2024, 2, 15, 11, 0),
    read: true,
  },
  {
    id: 8,
    sender: 0, // Current user
    recipient: 1, // Sarah Johnson
    content:
      "Let me check my schedule... Yes, I can do Friday at the same time (10:00 AM). I'll update it in the system right away.",
    timestamp: new Date(2024, 2, 15, 11, 15),
    read: true,
  },
  {
    id: 9,
    sender: 1, // Sarah Johnson
    recipient: 0, // Current user
    content: "Thank you for the update on Alex's progress!",
    timestamp: new Date(2024, 2, 15, 14, 30),
    read: true,
  },
]

export default function MessagesPage() {
  const [selectedContact, setSelectedContact] = useState(CONTACTS[0])
  const [messageText, setMessageText] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  // Filter contacts based on search query
  const filteredContacts = searchQuery
    ? CONTACTS.filter(
        (contact) =>
          contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          contact.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (contact.client && contact.client.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    : CONTACTS

  // Handle sending a new message
  const handleSendMessage = () => {
    if (messageText.trim() === "") return

    // In a real app, you would send the message to the server here
    console.log(`Sending message to ${selectedContact.name}: ${messageText}`)

    // Clear the input field
    setMessageText("")
  }

  // Format timestamp for messages
  const formatMessageTime = (date) => {
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return format(date, "h:mm a")
    } else if (date.toDateString() === yesterday.toDateString()) {
      return `Yesterday, ${format(date, "h:mm a")}`
    } else {
      return format(date, "MMM d, h:mm a")
    }
  }

  return (
    <div className="flex min-h-screen flex-col">     

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Messages</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Contacts List */}
          <Card className="md:col-span-1 flex flex-col h-full">
            <CardHeader className="pb-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search contacts..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto">
              <div className="space-y-1">
                {filteredContacts.map((contact) => (
                  <div
                    key={contact.id}
                    className={`flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-muted/50 ${
                      selectedContact.id === contact.id ? "bg-muted" : ""
                    }`}
                    onClick={() => setSelectedContact(contact)}
                  >
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={contact.avatar} alt={contact.name} />
                        <AvatarFallback>
                          {contact.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span
                        className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${
                          contact.status === "online" ? "bg-green-500" : "bg-gray-300"
                        }`}
                      ></span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium truncate">{contact.name}</p>
                        <p className="text-xs text-muted-foreground">{format(contact.lastMessageTime, "MMM d")}</p>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-muted-foreground truncate">
                          {contact.role}
                          {contact.client ? ` • ${contact.client}` : ""}
                        </p>
                        {contact.unread > 0 && (
                          <Badge
                            variant="default"
                            className="ml-auto h-5 w-5 rounded-full p-0 text-xs flex items-center justify-center"
                          >
                            {contact.unread}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chat Area */}
          <Card className="md:col-span-2 flex flex-col h-full">
            {/* Chat Header */}
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 border-b">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={selectedContact.avatar} alt={selectedContact.name} />
                  <AvatarFallback>
                    {selectedContact.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg">{selectedContact.name}</CardTitle>
                  <CardDescription>
                    {selectedContact.role}
                    {selectedContact.client ? ` • ${selectedContact.client}` : ""}
                    <span
                      className={`ml-2 inline-block h-2 w-2 rounded-full ${
                        selectedContact.status === "online" ? "bg-green-500" : "bg-gray-300"
                      }`}
                    ></span>
                    <span className="ml-1 text-xs">{selectedContact.status === "online" ? "Online" : "Offline"}</span>
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon">
                  <Phone className="h-4 w-4" />
                  <span className="sr-only">Call</span>
                </Button>
                <Button variant="ghost" size="icon">
                  <Video className="h-4 w-4" />
                  <span className="sr-only">Video Call</span>
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                      <span className="sr-only">More Options</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Options</DropdownMenuLabel>
                    <DropdownMenuItem>View Contact</DropdownMenuItem>
                    <DropdownMenuItem>Search in Conversation</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>Mute Notifications</DropdownMenuItem>
                    <DropdownMenuItem>Block Contact</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>

            {/* Messages */}
            <CardContent className="flex-1 overflow-auto p-4 space-y-4">
              {MESSAGES.map((message) => (
                <div key={message.id} className={`flex ${message.sender === 0 ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] ${message.sender === 0 ? "bg-primary text-primary-foreground" : "bg-muted"} rounded-lg p-3`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs text-right mt-1 opacity-70">{formatMessageTime(message.timestamp)}</p>
                  </div>
                </div>
              ))}
            </CardContent>

            {/* Message Input */}
            <div className="p-4 border-t">
              <div className="flex items-end gap-2">
                <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
                  <Paperclip className="h-4 w-4" />
                  <span className="sr-only">Attach File</span>
                </Button>
                <Textarea
                  placeholder="Type a message..."
                  className="min-h-10 flex-1 resize-none"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSendMessage()
                    }
                  }}
                />
                <Button
                  size="icon"
                  className="rounded-full h-8 w-8"
                  onClick={handleSendMessage}
                  disabled={messageText.trim() === ""}
                >
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}

