"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ChevronLeft, Search, Filter, Plus, FileText, BarChart3, ClipboardList } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock assessment data
const ASSESSMENTS = [
  {
    id: 1,
    name: "ABLLS-R",
    fullName: "Assessment of Basic Language and Learning Skills-Revised",
    type: "Language & Learning",
    lastUpdated: new Date(2024, 1, 15),
    status: "Active",
  },
  {
    id: 2,
    name: "VB-MAPP",
    fullName: "Verbal Behavior Milestones Assessment and Placement Program",
    type: "Verbal Behavior",
    lastUpdated: new Date(2023, 11, 10),
    status: "Active",
  },
  {
    id: 3,
    name: "AFLS",
    fullName: "Assessment of Functional Living Skills",
    type: "Functional Skills",
    lastUpdated: new Date(2024, 0, 20),
    status: "Active",
  },
  {
    id: 4,
    name: "ADOS-2",
    fullName: "Autism Diagnostic Observation Schedule, Second Edition",
    type: "Diagnostic",
    lastUpdated: new Date(2023, 9, 5),
    status: "Active",
  },
  {
    id: 5,
    name: "Vineland-3",
    fullName: "Vineland Adaptive Behavior Scales, Third Edition",
    type: "Adaptive Behavior",
    lastUpdated: new Date(2024, 2, 1),
    status: "Active",
  },
]

// Mock client assessments
const CLIENT_ASSESSMENTS = [
  {
    id: 1,
    client: "Alex Johnson",
    assessment: "ABLLS-R",
    date: new Date(2024, 1, 15),
    administrator: "Dr. Sarah Miller",
    status: "Completed",
  },
  {
    id: 2,
    client: "Maya Patel",
    assessment: "VB-MAPP",
    date: new Date(2024, 0, 20),
    administrator: "Thomas Wilson",
    status: "Completed",
  },
  {
    id: 3,
    client: "Ethan Williams",
    assessment: "AFLS",
    date: new Date(2024, 2, 5),
    administrator: "Jessica Taylor",
    status: "In Progress",
  },
  {
    id: 4,
    client: "Sophia Garcia",
    assessment: "Vineland-3",
    date: new Date(2024, 1, 28),
    administrator: "Dr. Sarah Miller",
    status: "Completed",
  },
  {
    id: 5,
    client: "Noah Chen",
    assessment: "ADOS-2",
    date: new Date(2024, 2, 10),
    administrator: "Thomas Wilson",
    status: "Scheduled",
  },
]

export default function AssessmentsPage() {
  const [activeTab, setActiveTab] = useState("client")

  return (
    <div className="flex min-h-screen flex-col">     

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Assessments</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search assessments..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Assessment
            </Button>
          </div>
        </div>

        <Tabs defaultValue="client" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="client">Client Assessments</TabsTrigger>
            <TabsTrigger value="library">Assessment Library</TabsTrigger>
            <TabsTrigger value="reports">Assessment Reports</TabsTrigger>
          </TabsList>

          {/* Client Assessments Tab */}
          <TabsContent value="client">
            <Card>
              <CardHeader>
                <CardTitle>Client Assessments</CardTitle>
                <CardDescription>View and manage all client assessments</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client</TableHead>
                      <TableHead>Assessment</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Administrator</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {CLIENT_ASSESSMENTS.map((assessment) => (
                      <TableRow key={assessment.id}>
                        <TableCell className="font-medium">{assessment.client}</TableCell>
                        <TableCell>{assessment.assessment}</TableCell>
                        <TableCell>{format(assessment.date, "MMM d, yyyy")}</TableCell>
                        <TableCell>{assessment.administrator}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              assessment.status === "Completed"
                                ? "outline"
                                : assessment.status === "In Progress"
                                  ? "secondary"
                                  : "default"
                            }
                            className={
                              assessment.status === "Completed"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : assessment.status === "In Progress"
                                  ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                  : "bg-blue-50 text-blue-700 border-blue-200"
                            }
                          >
                            {assessment.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <Button variant="ghost" size="sm">
                              <BarChart3 className="h-4 w-4 mr-1" />
                              Results
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Assessment Library Tab */}
          <TabsContent value="library">
            <Card>
              <CardHeader>
                <CardTitle>Assessment Library</CardTitle>
                <CardDescription>Available assessment tools and protocols</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Full Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ASSESSMENTS.map((assessment) => (
                      <TableRow key={assessment.id}>
                        <TableCell className="font-medium">{assessment.name}</TableCell>
                        <TableCell>{assessment.fullName}</TableCell>
                        <TableCell>{assessment.type}</TableCell>
                        <TableCell>{format(assessment.lastUpdated, "MMM d, yyyy")}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            {assessment.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <Button variant="ghost" size="sm">
                              <ClipboardList className="h-4 w-4 mr-1" />
                              Use
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Assessment Reports Tab */}
          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Assessment Reports</CardTitle>
                <CardDescription>Generate and view assessment reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <Card className="cursor-pointer hover:bg-muted/50">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium">Individual Progress</CardTitle>
                      <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Track individual client progress across assessments
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="cursor-pointer hover:bg-muted/50">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium">Comparative Analysis</CardTitle>
                      <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Compare assessment results across clients or time periods
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="cursor-pointer hover:bg-muted/50">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium">Assessment Summary</CardTitle>
                      <FileText className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">Generate comprehensive assessment summary reports</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <BarChart3 className="h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Generate Assessment Report</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    Select a report type above to generate a new assessment report
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

