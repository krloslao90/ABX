import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ChevronLeft, Search, Plus, Mail, Calendar, FileText, Clock, BarChart3 } from "lucide-react"
import Link from "next/link"

// Mock staff data
const STAFF = [
  {
    id: 1,
    name: "Dr. Sarah Miller",
    role: "Speech Therapist",
    status: "Active",
    email: "sarah.miller@example.com",
    phone: "(555) 123-4567",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 12,
    hoursThisWeek: 32,
    certifications: ["BCBA", "Licensed SLP"],
    nextAvailable: "Today, 3:00 PM",
  },
  {
    id: 2,
    name: "Thomas Wilson",
    role: "Behavioral Therapist",
    status: "Active",
    email: "thomas.wilson@example.com",
    phone: "(555) 234-5678",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 10,
    hoursThisWeek: 28,
    certifications: ["RBT", "ABA Certified"],
    nextAvailable: "Tomorrow, 9:00 AM",
  },
  {
    id: 3,
    name: "Jessica Taylor",
    role: "Occupational Therapist",
    status: "Active",
    email: "jessica.taylor@example.com",
    phone: "(555) 345-6789",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 8,
    hoursThisWeek: 24,
    certifications: ["OTR/L", "Sensory Integration Certified"],
    nextAvailable: "Today, 1:00 PM",
  },
  {
    id: 4,
    name: "Michael Brown",
    role: "Clinical Director",
    status: "Active",
    email: "michael.brown@example.com",
    phone: "(555) 456-7890",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 5,
    hoursThisWeek: 20,
    certifications: ["BCBA-D", "Licensed Psychologist"],
    nextAvailable: "Thursday, 10:00 AM",
  },
  {
    id: 5,
    name: "Amanda Garcia",
    role: "Behavioral Therapist",
    status: "On Leave",
    email: "amanda.garcia@example.com",
    phone: "(555) 567-8901",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 0,
    hoursThisWeek: 0,
    certifications: ["RBT"],
    nextAvailable: "Returns June 15, 2024",
  },
  {
    id: 6,
    name: "David Chen",
    role: "Speech Therapist",
    status: "Active",
    email: "david.chen@example.com",
    phone: "(555) 678-9012",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 9,
    hoursThisWeek: 30,
    certifications: ["CCC-SLP", "PROMPT Certified"],
    nextAvailable: "Tomorrow, 2:00 PM",
  },
  {
    id: 7,
    name: "Rachel Williams",
    role: "Behavioral Therapist",
    status: "Part-Time",
    email: "rachel.williams@example.com",
    phone: "(555) 789-0123",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 6,
    hoursThisWeek: 15,
    certifications: ["RBT", "ABA Certified"],
    nextAvailable: "Friday, 9:00 AM",
  },
  {
    id: 8,
    name: "James Johnson",
    role: "Occupational Therapist",
    status: "Active",
    email: "james.johnson@example.com",
    phone: "(555) 890-1234",
    avatar: "/placeholder.svg?height=40&width=40",
    clients: 7,
    hoursThisWeek: 26,
    certifications: ["OTR/L"],
    nextAvailable: "Today, 4:00 PM",
  },
]

export default function StaffPage() {
  return (
    <div className="flex min-h-screen flex-col">     

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Staff Management</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search staff..." className="w-[250px] pl-8" />
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Staff Member
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="mb-6">
          <TabsList>
            <TabsTrigger value="all">All Staff</TabsTrigger>
            <TabsTrigger value="therapists">Therapists</TabsTrigger>
            <TabsTrigger value="admin">Administrative</TabsTrigger>
            <TabsTrigger value="management">Management</TabsTrigger>
          </TabsList>
        </Tabs>

        <Card>
          <CardHeader>
            <CardTitle>Staff Directory</CardTitle>
            <CardDescription>Manage and view all staff information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {STAFF.map((staff) => (
                <div
                  key={staff.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50"
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={staff.avatar} alt={staff.name} />
                      <AvatarFallback>
                        {staff.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{staff.name}</p>
                      <p className="text-sm text-muted-foreground">{staff.role}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="hidden md:flex flex-col items-center">
                      <p className="text-sm font-medium">{staff.clients}</p>
                      <p className="text-xs text-muted-foreground">Clients</p>
                    </div>
                    <div className="hidden md:flex flex-col items-center">
                      <p className="text-sm font-medium">{staff.hoursThisWeek}</p>
                      <p className="text-xs text-muted-foreground">Hours</p>
                    </div>
                    <div className="hidden lg:block text-right">
                      <p className="text-sm font-medium">Next Available</p>
                      <p className="text-sm text-muted-foreground">{staff.nextAvailable}</p>
                    </div>
                    <Badge
                      variant={
                        staff.status === "Active"
                          ? "default"
                          : staff.status === "On Leave"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {staff.status}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Staff Availability</CardTitle>
              <CardDescription>Today's schedule overview</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {STAFF.filter((s) => s.status === "Active")
                  .slice(0, 4)
                  .map((staff) => (
                    <div key={staff.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>
                            {staff.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{staff.name}</p>
                          <p className="text-xs text-muted-foreground">{staff.role}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{staff.nextAvailable.split(",")[1]}</span>
                      </div>
                    </div>
                  ))}
              </div>
              <div className="mt-4 pt-4 border-t">
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/calendar">
                    <Calendar className="mr-2 h-4 w-4" />
                    View Full Schedule
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Workload Distribution</CardTitle>
              <CardDescription>Client and hour allocation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {STAFF.filter((s) => s.status === "Active")
                  .slice(0, 4)
                  .map((staff) => (
                    <div key={staff.id} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{staff.name}</p>
                        <span className="text-sm text-muted-foreground">
                          {staff.hoursThisWeek} hrs / {staff.clients} clients
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary rounded-full"
                          style={{ width: `${(staff.hoursThisWeek / 40) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
              </div>
              <div className="mt-4 pt-4 border-t">
                <Button variant="outline" className="w-full">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  View Detailed Reports
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest staff updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                    <FileText className="h-4 w-4 text-blue-700" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Session Notes Submitted</p>
                    <p className="text-xs text-muted-foreground">Dr. Sarah Miller • 1 hour ago</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100">
                    <Calendar className="h-4 w-4 text-green-700" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Schedule Updated</p>
                    <p className="text-xs text-muted-foreground">Thomas Wilson • 3 hours ago</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-100">
                    <Mail className="h-4 w-4 text-purple-700" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Leave Request Submitted</p>
                    <p className="text-xs text-muted-foreground">Jessica Taylor • 5 hours ago</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-100">
                    <BarChart3 className="h-4 w-4 text-orange-700" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Monthly Report Generated</p>
                    <p className="text-xs text-muted-foreground">Michael Brown • Yesterday</p>
                  </div>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t">
                <Button variant="outline" className="w-full">
                  View All Activity
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

