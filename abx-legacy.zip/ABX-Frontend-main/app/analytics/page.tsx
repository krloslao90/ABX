'use client';

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ChevronLeft, Download, Calendar, BarChart3, Users, Clock } from "lucide-react"
import Link from "next/link"
import { Line, LineChart, Bar, BarChart, Pie, PieChart as RePieChart, Cell, Legend, Tooltip } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Mock analytics data
const CLIENT_PROGRESS_DATA = [
  { month: "Jan", progress: 65 },
  { month: "Feb", progress: 68 },
  { month: "Mar", progress: 72 },
  { month: "Apr", progress: 75 },
  { month: "May", progress: 80 },
  { month: "Jun", progress: 82 },
  { month: "Jul", progress: 85 },
  { month: "Aug", progress: 87 },
  { month: "Sep", progress: 90 },
  { month: "Oct", progress: 92 },
  { month: "Nov", progress: 94 },
  { month: "Dec", progress: 96 },
]

const SESSION_DATA = [
  { month: "Jan", speech: 45, behavioral: 32, occupational: 28 },
  { month: "Feb", speech: 48, behavioral: 35, occupational: 30 },
  { month: "Mar", speech: 52, behavioral: 38, occupational: 32 },
  { month: "Apr", speech: 55, behavioral: 42, occupational: 35 },
  { month: "May", speech: 58, behavioral: 45, occupational: 38 },
  { month: "Jun", speech: 60, behavioral: 48, occupational: 40 },
  { month: "Jul", speech: 62, behavioral: 50, occupational: 42 },
  { month: "Aug", speech: 65, behavioral: 52, occupational: 45 },
  { month: "Sep", speech: 68, behavioral: 55, occupational: 48 },
  { month: "Oct", speech: 70, behavioral: 58, occupational: 50 },
  { month: "Nov", speech: 72, behavioral: 60, occupational: 52 },
  { month: "Dec", speech: 75, behavioral: 62, occupational: 55 },
]

const THERAPY_DISTRIBUTION = [
  { name: "Speech Therapy", value: 45, color: "#4f46e5" },
  { name: "Behavioral Therapy", value: 35, color: "#10b981" },
  { name: "Occupational Therapy", value: 20, color: "#f59e0b" },
]

const GOAL_ACHIEVEMENT = [
  { name: "Achieved", value: 68, color: "#10b981" },
  { name: "In Progress", value: 24, color: "#f59e0b" },
  { name: "Not Started", value: 8, color: "#ef4444" },
]

export default function AnalyticsPage() {
  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Analytics & Reporting</h2>
          <div className="ml-auto flex items-center gap-2">
            <Select defaultValue="thisYear">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="thisMonth">This Month</SelectItem>
                <SelectItem value="lastMonth">Last Month</SelectItem>
                <SelectItem value="thisQuarter">This Quarter</SelectItem>
                <SelectItem value="thisYear">This Year</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">42</div>
              <p className="text-xs text-muted-foreground">+8% from last period</p>
              <div className="mt-4 h-1 w-full bg-muted">
                <div className="h-1 bg-primary" style={{ width: "75%" }}></div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Sessions Completed</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">386</div>
              <p className="text-xs text-muted-foreground">+12% from last period</p>
              <div className="mt-4 h-1 w-full bg-muted">
                <div className="h-1 bg-primary" style={{ width: "85%" }}></div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Therapy Hours</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,248</div>
              <p className="text-xs text-muted-foreground">+5% from last period</p>
              <div className="mt-4 h-1 w-full bg-muted">
                <div className="h-1 bg-primary" style={{ width: "68%" }}></div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Goal Achievement</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">68%</div>
              <p className="text-xs text-muted-foreground">+15% from last period</p>
              <div className="mt-4 h-1 w-full bg-muted">
                <div className="h-1 bg-primary" style={{ width: "68%" }}></div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="mb-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="clients">Client Progress</TabsTrigger>
            <TabsTrigger value="sessions">Session Analysis</TabsTrigger>
            <TabsTrigger value="goals">Goal Tracking</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Client Progress Trends</CardTitle>
              <CardDescription>Average progress across all clients</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  progress: {
                    label: "Progress",
                    color: "hsl(var(--chart-1))",
                  },
                }}
                className="h-[300px]"
              >
                <LineChart data={CLIENT_PROGRESS_DATA} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                  <Line
                    type="monotone"
                    dataKey="progress"
                    stroke="var(--color-progress)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                </LineChart>
              </ChartContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Session Distribution</CardTitle>
              <CardDescription>Breakdown by therapy type</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  speech: {
                    label: "Speech Therapy",
                    color: "hsl(var(--chart-1))",
                  },
                  behavioral: {
                    label: "Behavioral Therapy",
                    color: "hsl(var(--chart-2))",
                  },
                  occupational: {
                    label: "Occupational Therapy",
                    color: "hsl(var(--chart-3))",
                  },
                }}
                className="h-[300px]"
              >
                <BarChart data={SESSION_DATA.slice(-6)} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                  <Bar dataKey="speech" fill="var(--color-speech)" stackId="a" />
                  <Bar dataKey="behavioral" fill="var(--color-behavioral)" stackId="a" />
                  <Bar dataKey="occupational" fill="var(--color-occupational)" stackId="a" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Therapy Type Distribution</CardTitle>
              <CardDescription>Percentage of each therapy type</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <div className="w-[300px] h-[300px]">
                <RePieChart width={300} height={300}>
                  <Pie
                    data={THERAPY_DISTRIBUTION}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {THERAPY_DISTRIBUTION.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </RePieChart>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Goal Achievement Status</CardTitle>
              <CardDescription>Overall progress on treatment goals</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <div className="w-[300px] h-[300px]">
                <RePieChart width={300} height={300}>
                  <Pie
                    data={GOAL_ACHIEVEMENT}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {GOAL_ACHIEVEMENT.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </RePieChart>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

