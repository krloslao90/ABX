"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { FormLabel } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { ChevronLeft, ChevronRight, Plus, CalendarIcon, Users, Info, Edit, Trash2 } from "lucide-react"
import {
  format,
  addDays,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameDay,
  isSameMonth,
  addMonths,
  subMonths,
} from "date-fns"
import { cn } from "@/lib/utils"

// Mock data for appointments
const APPOINTMENTS = [
  {
    id: 1,
    title: "Speech Therapy",
    client: "Alex Johnson",
    therapist: "Dr. Sarah Miller",
    date: new Date(2025, 2, 15, 9, 0),
    endTime: new Date(2025, 2, 15, 10, 0),
    type: "Speech",
    notes: "Focus on articulation exercises",
    status: "confirmed",
  },
  {
    id: 2,
    title: "Behavioral Assessment",
    client: "Maya Patel",
    therapist: "Thomas Wilson",
    date: new Date(2025, 2, 15, 11, 0),
    endTime: new Date(2025, 2, 15, 12, 30),
    type: "Behavioral",
    notes: "Initial assessment for new behavior plan",
    status: "confirmed",
  },
  {
    id: 3,
    title: "Occupational Therapy",
    client: "Ethan Williams",
    therapist: "Jessica Taylor",
    date: new Date(2025, 2, 16, 14, 0),
    endTime: new Date(2025, 2, 16, 15, 0),
    type: "Occupational",
    notes: "Fine motor skills development",
    status: "confirmed",
  },
  {
    id: 4,
    title: "Parent Training",
    client: "Sophia Garcia",
    therapist: "Thomas Wilson",
    date: new Date(2025, 2, 17, 16, 0),
    endTime: new Date(2025, 2, 17, 17, 0),
    type: "Parent",
    notes: "Review home strategies and progress",
    status: "pending",
  },
  {
    id: 5,
    title: "Initial Assessment",
    client: "Noah Chen",
    therapist: "Dr. Sarah Miller",
    date: new Date(2025, 2, 18, 10, 0),
    endTime: new Date(2025, 2, 18, 11, 30),
    type: "Assessment",
    notes: "New client intake and assessment",
    status: "confirmed",
  },
  {
    id: 6,
    title: "Group Social Skills",
    client: "Multiple Clients",
    therapist: "Jessica Taylor",
    date: new Date(2025, 2, 19, 15, 0),
    endTime: new Date(2025, 2, 19, 16, 0),
    type: "Group",
    notes: "Social skills development in group setting",
    status: "confirmed",
  },
  {
    id: 7,
    title: "Follow-up Session",
    client: "Alex Johnson",
    therapist: "Dr. Sarah Miller",
    date: new Date(2025, 2, 20, 9, 0),
    endTime: new Date(2025, 2, 20, 10, 0),
    type: "Speech",
    notes: "Follow-up on progress with articulation",
    status: "confirmed",
  },
]

// Appointment types with colors
const APPOINTMENT_TYPES = {
  Speech: { color: "bg-blue-100 text-blue-800 border-blue-200" },
  Behavioral: { color: "bg-green-100 text-green-800 border-green-200" },
  Occupational: { color: "bg-purple-100 text-purple-800 border-purple-200" },
  Assessment: { color: "bg-orange-100 text-orange-800 border-orange-200" },
  Parent: { color: "bg-pink-100 text-pink-800 border-pink-200" },
  Group: { color: "bg-indigo-100 text-indigo-800 border-indigo-200" },
}

// Mock data for clients and therapists
const CLIENTS = [
  { id: 1, name: "Alex Johnson" },
  { id: 2, name: "Maya Patel" },
  { id: 3, name: "Ethan Williams" },
  { id: 4, name: "Sophia Garcia" },
  { id: 5, name: "Noah Chen" },
]

const THERAPISTS = [
  { id: 1, name: "Dr. Sarah Miller" },
  { id: 2, name: "Thomas Wilson" },
  { id: 3, name: "Jessica Taylor" },
]

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(() => {
    const now = new Date();
    return isNaN(now) ? new Date() : now;
  });
  const [calendarView, setCalendarView] = useState("month")
  const [selectedAppointment, setSelectedAppointment] = useState(null)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isViewModalOpen, setIsViewModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)

  // Helper functions for date manipulation
  const goToPreviousPeriod = () => {
    if (calendarView === "day") {
      setCurrentDate((prev) => addDays(prev, -1))
      setSelectedDate((prev) => addDays(prev, -1))
    } else if (calendarView === "week") {
      setCurrentDate((prev) => addDays(prev, -7))
      setSelectedDate((prev) => addDays(prev, -7))
    } else {
      setCurrentDate((prev) => subMonths(prev, 1))
    }
  }

  const goToNextPeriod = () => {
    if (calendarView === "day") {
      setCurrentDate((prev) => addDays(prev, 1))
      setSelectedDate((prev) => addDays(prev, 1))
    } else if (calendarView === "week") {
      setCurrentDate((prev) => addDays(prev, 7))
      setSelectedDate((prev) => addDays(prev, 7))
    } else {
      setCurrentDate((prev) => addMonths(prev, 1))
    }
  }

  const goToToday = () => {
    setCurrentDate(new Date())
    setSelectedDate(new Date())
  }

  // Filter appointments for the selected date
  const getAppointmentsForDate = (date) => {
    return APPOINTMENTS.filter((appointment) => {
      if (!appointment.date || isNaN(new Date(appointment.date))) {
        console.warn("Skipping invalid appointment date:", appointment);
        return false;
      }
      return isSameDay(new Date(appointment.date), date);
    });
  };
  

  // Get appointments for the selected date
  const selectedDateAppointments = getAppointmentsForDate(selectedDate)

  // Get the week interval for week view
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 0 })
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 0 })
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd })

  // Handle appointment selection
  const handleAppointmentClick = (appointment) => {
    setSelectedAppointment(appointment)
    setIsViewModalOpen(true)
  }

  // Handle edit appointment
  const handleEditAppointment = () => {
    setIsViewModalOpen(false)
    setIsEditModalOpen(true)
  }

  // Handle new appointment
  const handleNewAppointment = () => {
    setSelectedAppointment(null)
    setIsCreateModalOpen(true)
  }

  // Format time from Date object
  const formatTime = (date) => {
    if (!date || isNaN(new Date(date))) {
      console.error("Invalid date:", date);
      return "Invalid date";
    }
    return format(new Date(date), "h:mm a");
  };
  

  // Get appointment duration in minutes
  const getAppointmentDuration = (start, end) => {
    return Math.round((end.getTime() - start.getTime()) / (1000 * 60))
  }

  return (
    <div className="flex min-h-screen flex-col">
      {/* Main Content */}
      <main className="flex-1 container p-6">
        <div className="flex items-center mb-6">
          <h2 className="text-3xl font-bold tracking-tight">Calendar</h2>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="outline" onClick={goToToday}>
              Today
            </Button>
            <Select value={calendarView} onValueChange={setCalendarView}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="View" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Day</SelectItem>
                <SelectItem value="week">Week</SelectItem>
                <SelectItem value="month">Month</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleNewAppointment}>
              <Plus className="mr-2 h-4 w-4" />
              New Appointment
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center">
            <div>
              <CardTitle>
                {calendarView === "day" && format(currentDate, "MMMM d, yyyy")}
                {calendarView === "week" && `${format(weekStart, "MMM d")} - ${format(weekEnd, "MMM d, yyyy")}`}
                {calendarView === "month" && format(currentDate, "MMMM yyyy")}
              </CardTitle>
              <CardDescription>
                {calendarView === "day" && "Daily schedule"}
                {calendarView === "week" && "Weekly overview"}
                {calendarView === "month" && "Monthly overview"}
              </CardDescription>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={goToPreviousPeriod}>
                <ChevronLeft className="h-4 w-4" />
                <span className="sr-only">Previous</span>
              </Button>
              <Button variant="outline" size="icon" onClick={goToNextPeriod}>
                <ChevronRight className="h-4 w-4" />
                <span className="sr-only">Next</span>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={calendarView} onValueChange={setCalendarView} className="w-full">
              <TabsList className="hidden">
                <TabsTrigger value="day">Day</TabsTrigger>
                <TabsTrigger value="week">Week</TabsTrigger>
                <TabsTrigger value="month">Month</TabsTrigger>
              </TabsList>

              {/* Day View */}
              <TabsContent value="day" className="mt-0">
                <div className="space-y-1">
                  {Array.from({ length: 12 }, (_, i) => i + 8).map((hour) => {
                    const currentHourDate = new Date(selectedDate)
                    currentHourDate.setHours(hour, 0, 0, 0)

                    const appointmentsAtHour = APPOINTMENTS.filter(
                      (appointment) =>
                        isSameDay(appointment.date, selectedDate) && appointment.date.getHours() === hour,
                    )

                    return (
                      <div key={hour} className="grid grid-cols-[80px_1fr] gap-4">
                        <div className="py-2 text-sm font-medium text-muted-foreground">
                          {hour % 12 || 12}:00 {hour >= 12 ? "PM" : "AM"}
                        </div>
                        {appointmentsAtHour.length > 0 ? (
                          <div className="space-y-2">
                            {appointmentsAtHour.map((appointment) => (
                              <div
                                key={appointment.id}
                                className={`rounded-md border p-3 cursor-pointer hover:bg-muted/50 ${
                                  APPOINTMENT_TYPES[appointment.type]?.color ||
                                  "bg-gray-100 text-gray-800 border-gray-200"
                                }`}
                                onClick={() => handleAppointmentClick(appointment)}
                              >
                                <div className="flex items-center justify-between">
                                  <div>
                                    <p className="font-medium">{appointment.title}</p>
                                    <p className="text-sm">
                                      {formatTime(appointment.date)} - {formatTime(appointment.endTime)} •{" "}
                                      {appointment.client}
                                    </p>
                                  </div>
                                  <Badge variant="outline">{appointment.type}</Badge>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="rounded-md border border-dashed p-3 hover:bg-muted/50">
                            <p className="text-sm text-muted-foreground text-center">Available</p>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </TabsContent>

              {/* Week View */}
              <TabsContent value="week" className="mt-0">
                <div className="grid grid-cols-7 gap-1">
                  {weekDays.map((day, i) => (
                    <div key={i} className="text-center p-2">
                      <div className={cn("font-medium text-sm mb-1", isSameDay(day, new Date()) && "text-primary")}>
                        {format(day, "EEE")}
                      </div>
                      <div
                        className={cn(
                          "h-8 w-8 rounded-full flex items-center justify-center mx-auto cursor-pointer",
                          isSameDay(day, selectedDate) && "bg-primary text-primary-foreground",
                          isSameDay(day, new Date()) && !isSameDay(day, selectedDate) && "border border-primary",
                        )}
                        onClick={() => setSelectedDate(day)}
                      >
                        {format(day, "d")}
                      </div>
                      <div className="mt-2 space-y-1">
                        {getAppointmentsForDate(day)
                          .slice(0, 3)
                          .map((appointment, idx) => (
                            <div
                              key={idx}
                              className={`text-xs p-1 rounded truncate cursor-pointer ${
                                APPOINTMENT_TYPES[appointment.type]?.color || "bg-gray-100 text-gray-800"
                              }`}
                              onClick={() => handleAppointmentClick(appointment)}
                            >
                              {formatTime(appointment.date)} {appointment.title}
                            </div>
                          ))}
                        {getAppointmentsForDate(day).length > 3 && (
                          <div className="text-xs text-center text-muted-foreground">
                            +{getAppointmentsForDate(day).length - 3} more
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 border-t pt-6">
                  <h3 className="font-medium mb-4">Appointments for {format(selectedDate, "MMMM d, yyyy")}</h3>
                  {selectedDateAppointments.length > 0 ? (
                    <div className="space-y-2">
                      {selectedDateAppointments.map((appointment) => (
                        <div
                          key={appointment.id}
                          className={`rounded-md border p-3 cursor-pointer hover:bg-muted/50 ${
                            APPOINTMENT_TYPES[appointment.type]?.color || "bg-gray-100 text-gray-800 border-gray-200"
                          }`}
                          onClick={() => handleAppointmentClick(appointment)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{appointment.title}</p>
                              <p className="text-sm">
                                {formatTime(appointment.date)} - {formatTime(appointment.endTime)} •{" "}
                                {appointment.client}
                              </p>
                            </div>
                            <Badge variant="outline">{appointment.type}</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No appointments scheduled for this day.</p>
                  )}
                </div>
              </TabsContent>

              {/* Month View */}
              <TabsContent value="month" className="mt-0">
                <div className="grid grid-cols-7 gap-1 mb-2">
                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                    <div key={day} className="text-center p-2 text-sm font-medium">
                      {day}
                    </div>
                  ))}
                </div>
                <div>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    month={currentDate}
                    className="rounded-md border"
                    components={{
                      Day: ({ day, ...props }) => {
                        if (!day || isNaN(new Date(day))) {
                          console.warn("Invalid day in Calendar:", day);
                          return null;
                        }
                        const appointments = getAppointmentsForDate(day)
                        const isSelected = isSameDay(day, selectedDate)
                        const isToday = isSameDay(day, new Date())
                        const isCurrentMonth = isSameMonth(day, currentDate)

                        return (
                          <div
                            {...props}
                            className={cn(
                              "h-14 w-full p-0 font-normal relative",
                              !isCurrentMonth && "text-muted-foreground opacity-50",
                              isSelected && "bg-muted",
                              isToday && !isSelected && "border border-primary",
                            )}
                          >
                            <div className="absolute top-1 right-1 text-xs">{format(day, "d")}</div>
                            <div className="mt-5 px-1">
                              {appointments.length > 0 && (
                                <div className="flex flex-col gap-0.5">
                                  {appointments.slice(0, 2).map((appointment, idx) => (
                                    <div
                                      key={idx}
                                      className={`text-xs p-0.5 rounded truncate ${
                                        APPOINTMENT_TYPES[appointment.type]?.color || "bg-gray-100 text-gray-800"
                                      }`}
                                    >
                                      {appointment.title}
                                    </div>
                                  ))}
                                  {appointments.length > 2 && (
                                    <div className="text-xs text-muted-foreground">+{appointments.length - 2} more</div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        )
                      },
                    }}
                  />
                </div>

                <div className="mt-6 border-t pt-6">
                  <h3 className="font-medium mb-4">Appointments for {format(selectedDate, "MMMM d, yyyy")}</h3>
                  {selectedDateAppointments.length > 0 ? (
                    <div className="space-y-2">
                      {selectedDateAppointments.map((appointment) => (
                        <div
                          key={appointment.id}
                          className={`rounded-md border p-3 cursor-pointer hover:bg-muted/50 ${
                            APPOINTMENT_TYPES[appointment.type]?.color || "bg-gray-100 text-gray-800 border-gray-200"
                          }`}
                          onClick={() => handleAppointmentClick(appointment)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{appointment.title}</p>
                              <p className="text-sm">
                                {formatTime(appointment.date)} - {formatTime(appointment.endTime)} •{" "}
                                {appointment.client}
                              </p>
                            </div>
                            <Badge variant="outline">{appointment.type}</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No appointments scheduled for this day.</p>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>

      {/* Create Appointment Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Appointment</DialogTitle>
            <DialogDescription>Schedule a new therapy session or appointment.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Title</FormLabel>
              <Input className="col-span-3" placeholder="Therapy Session" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Client</FormLabel>
              <Select defaultValue="1">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent>
                  {CLIENTS.map((client) => (
                    <SelectItem key={client.id} value={client.id.toString()}>
                      {client.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Therapist</FormLabel>
              <Select defaultValue="1">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select therapist" />
                </SelectTrigger>
                <SelectContent>
                  {THERAPISTS.map((therapist) => (
                    <SelectItem key={therapist.id} value={therapist.id.toString()}>
                      {therapist.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Date</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="col-span-3 justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(selectedDate, "PPP")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Start Time</FormLabel>
              <Select defaultValue="9">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select start time" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }, (_, i) => i + 8).map((hour) => (
                    <SelectItem key={hour} value={hour.toString()}>
                      {hour % 12 || 12}:00 {hour >= 12 ? "PM" : "AM"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Duration</FormLabel>
              <Select defaultValue="60">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="45">45 minutes</SelectItem>
                  <SelectItem value="60">60 minutes</SelectItem>
                  <SelectItem value="90">90 minutes</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Type</FormLabel>
              <Select defaultValue="Behavioral">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(APPOINTMENT_TYPES).map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Notes</FormLabel>
              <Textarea className="col-span-3" placeholder="Add any notes or details about this appointment" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsCreateModalOpen(false)}>Create Appointment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Appointment Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        {selectedAppointment && (
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{selectedAppointment.title}</DialogTitle>
              <DialogDescription>Appointment details</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge variant="outline">{selectedAppointment.type}</Badge>
                <Badge variant={selectedAppointment.status === "confirmed" ? "default" : "secondary"}>
                  {selectedAppointment.status === "confirmed" ? "Confirmed" : "Pending"}
                </Badge>
              </div>

              <div className="grid grid-cols-[24px_1fr] gap-4">
                <CalendarIcon className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Date & Time</p>
                  <p className="text-sm text-muted-foreground">{format(selectedAppointment.date, "MMMM d, yyyy")}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatTime(selectedAppointment.date)} - {formatTime(selectedAppointment.endTime)}(
                    {getAppointmentDuration(selectedAppointment.date, selectedAppointment.endTime)} minutes)
                  </p>
                </div>

                <Users className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">People</p>
                  <p className="text-sm text-muted-foreground">Client: {selectedAppointment.client}</p>
                  <p className="text-sm text-muted-foreground">Therapist: {selectedAppointment.therapist}</p>
                </div>

                <Info className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Notes</p>
                  <p className="text-sm text-muted-foreground">{selectedAppointment.notes}</p>
                </div>
              </div>
            </div>
            <DialogFooter className="flex justify-between">
              <div>
                <Button variant="destructive" size="sm">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Cancel Appointment
                </Button>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsViewModalOpen(false)}>
                  Close
                </Button>
                <Button onClick={handleEditAppointment}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>

      {/* Edit Appointment Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        {selectedAppointment && (
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Edit Appointment</DialogTitle>
              <DialogDescription>Make changes to the appointment details.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Title</FormLabel>
                <Input className="col-span-3" defaultValue={selectedAppointment.title} />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Client</FormLabel>
                <Select defaultValue={selectedAppointment.client}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {CLIENTS.map((client) => (
                      <SelectItem key={client.id} value={client.name}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Therapist</FormLabel>
                <Select defaultValue={selectedAppointment.therapist}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select therapist" />
                  </SelectTrigger>
                  <SelectContent>
                    {THERAPISTS.map((therapist) => (
                      <SelectItem key={therapist.id} value={therapist.name}>
                        {therapist.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="col-span-3 justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {format(selectedAppointment.date, "PPP")}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={selectedAppointment.date} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Start Time</FormLabel>
                <Select defaultValue={selectedAppointment.date.getHours().toString()}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select start time" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 12 }, (_, i) => i + 8).map((hour) => (
                      <SelectItem key={hour} value={hour.toString()}>
                        {hour % 12 || 12}:00 {hour >= 12 ? "PM" : "AM"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Duration</FormLabel>
                <Select
                  defaultValue={getAppointmentDuration(
                    selectedAppointment.date,
                    selectedAppointment.endTime,
                  ).toString()}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                    <SelectItem value="60">60 minutes</SelectItem>
                    <SelectItem value="90">90 minutes</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Type</FormLabel>
                <Select defaultValue={selectedAppointment.type}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.keys(APPOINTMENT_TYPES).map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Status</FormLabel>
                <Select defaultValue={selectedAppointment.status}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <FormLabel className="text-right">Notes</FormLabel>
                <Textarea className="col-span-3" defaultValue={selectedAppointment.notes} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsEditModalOpen(false)}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  )
}

