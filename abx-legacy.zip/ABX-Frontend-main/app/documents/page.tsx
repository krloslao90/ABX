"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, Search, Filter, FileText, Download, Upload, File, Share, MoreHorizontal } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock document data
const DOCUMENTS = [
  {
    id: 1,
    name: "Treatment Plan - Alex Johnson.pdf",
    type: "Treatment Plan",
    client: "Alex Johnson",
    createdBy: "Dr. Sarah Miller",
    createdDate: new Date(2024, 1, 15),
    size: "1.2 MB",
    status: "Final",
  },
  {
    id: 2,
    name: "Progress Report - Q1 2024 - Alex Johnson.pdf",
    type: "Progress Report",
    client: "Alex Johnson",
    createdBy: "Dr. Sarah Miller",
    createdDate: new Date(2024, 2, 10),
    size: "2.4 MB",
    status: "Final",
  },
  {
    id: 3,
    name: "Assessment Results - ABLLS-R - Maya Patel.pdf",
    type: "Assessment",
    client: "Maya Patel",
    createdBy: "Thomas Wilson",
    createdDate: new Date(2024, 0, 20),
    size: "3.1 MB",
    status: "Final",
  },
  {
    id: 4,
    name: "Treatment Plan - Maya Patel.pdf",
    type: "Treatment Plan",
    client: "Maya Patel",
    createdBy: "Thomas Wilson",
    createdDate: new Date(2024, 0, 25),
    size: "1.5 MB",
    status: "Final",
  },
  {
    id: 5,
    name: "Consent Forms - Ethan Williams.pdf",
    type: "Consent",
    client: "Ethan Williams",
    createdBy: "Jessica Taylor",
    createdDate: new Date(2023, 11, 5),
    size: "0.8 MB",
    status: "Final",
  },
  {
    id: 6,
    name: "Treatment Plan - Draft - Sophia Garcia.pdf",
    type: "Treatment Plan",
    client: "Sophia Garcia",
    createdBy: "Thomas Wilson",
    createdDate: new Date(2024, 2, 5),
    size: "1.3 MB",
    status: "Draft",
  },
]

// Mock templates
const TEMPLATES = [
  {
    id: 1,
    name: "Treatment Plan Template.docx",
    type: "Treatment Plan",
    createdBy: "Admin",
    createdDate: new Date(2023, 8, 15),
    size: "0.5 MB",
  },
  {
    id: 2,
    name: "Progress Report Template.docx",
    type: "Progress Report",
    createdBy: "Admin",
    createdDate: new Date(2023, 8, 15),
    size: "0.4 MB",
  },
  {
    id: 3,
    name: "Assessment Report Template.docx",
    type: "Assessment",
    createdBy: "Admin",
    createdDate: new Date(2023, 8, 15),
    size: "0.6 MB",
  },
  {
    id: 4,
    name: "Consent Form Template.docx",
    type: "Consent",
    createdBy: "Admin",
    createdDate: new Date(2023, 8, 15),
    size: "0.3 MB",
  },
  {
    id: 5,
    name: "Session Notes Template.docx",
    type: "Session Notes",
    createdBy: "Admin",
    createdDate: new Date(2023, 8, 15),
    size: "0.2 MB",
  },
]

export default function DocumentsPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)
  const [selectedDocType, setSelectedDocType] = useState("treatment")

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Documents</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search documents..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button onClick={() => setIsUploadDialogOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">All Documents</TabsTrigger>
            <TabsTrigger value="treatment">Treatment Plans</TabsTrigger>
            <TabsTrigger value="progress">Progress Reports</TabsTrigger>
            <TabsTrigger value="assessment">Assessments</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          {/* All Documents Tab */}
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>Document Library</CardTitle>
                <CardDescription>Access and manage all documents</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DOCUMENTS.map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {doc.name}
                        </TableCell>
                        <TableCell>{doc.type}</TableCell>
                        <TableCell>{doc.client}</TableCell>
                        <TableCell>{doc.createdBy}</TableCell>
                        <TableCell>{format(doc.createdDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{doc.size}</TableCell>
                        <TableCell>
                          <Badge
                            variant={doc.status === "Final" ? "outline" : "secondary"}
                            className={
                              doc.status === "Final"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : "bg-yellow-50 text-yellow-700 border-yellow-200"
                            }
                          >
                            {doc.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Download</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Share className="h-4 w-4" />
                              <span className="sr-only">Share</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Treatment Plans Tab */}
          <TabsContent value="treatment">
            <Card>
              <CardHeader>
                <CardTitle>Treatment Plans</CardTitle>
                <CardDescription>Access and manage treatment plan documents</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DOCUMENTS.filter((doc) => doc.type === "Treatment Plan").map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {doc.name}
                        </TableCell>
                        <TableCell>{doc.client}</TableCell>
                        <TableCell>{doc.createdBy}</TableCell>
                        <TableCell>{format(doc.createdDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{doc.size}</TableCell>
                        <TableCell>
                          <Badge
                            variant={doc.status === "Final" ? "outline" : "secondary"}
                            className={
                              doc.status === "Final"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : "bg-yellow-50 text-yellow-700 border-yellow-200"
                            }
                          >
                            {doc.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Download</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Share className="h-4 w-4" />
                              <span className="sr-only">Share</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Progress Reports Tab */}
          <TabsContent value="progress">
            <Card>
              <CardHeader>
                <CardTitle>Progress Reports</CardTitle>
                <CardDescription>Access and manage progress report documents</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DOCUMENTS.filter((doc) => doc.type === "Progress Report").map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {doc.name}
                        </TableCell>
                        <TableCell>{doc.client}</TableCell>
                        <TableCell>{doc.createdBy}</TableCell>
                        <TableCell>{format(doc.createdDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{doc.size}</TableCell>
                        <TableCell>
                          <Badge
                            variant={doc.status === "Final" ? "outline" : "secondary"}
                            className={
                              doc.status === "Final"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : "bg-yellow-50 text-yellow-700 border-yellow-200"
                            }
                          >
                            {doc.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Download</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Share className="h-4 w-4" />
                              <span className="sr-only">Share</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Assessment Tab */}
          <TabsContent value="assessment">
            <Card>
              <CardHeader>
                <CardTitle>Assessment Documents</CardTitle>
                <CardDescription>Access and manage assessment documents</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DOCUMENTS.filter((doc) => doc.type === "Assessment").map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {doc.name}
                        </TableCell>
                        <TableCell>{doc.client}</TableCell>
                        <TableCell>{doc.createdBy}</TableCell>
                        <TableCell>{format(doc.createdDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{doc.size}</TableCell>
                        <TableCell>
                          <Badge
                            variant={doc.status === "Final" ? "outline" : "secondary"}
                            className={
                              doc.status === "Final"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : "bg-yellow-50 text-yellow-700 border-yellow-200"
                            }
                          >
                            {doc.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Download</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Share className="h-4 w-4" />
                              <span className="sr-only">Share</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates">
            <Card>
              <CardHeader>
                <CardTitle>Document Templates</CardTitle>
                <CardDescription>Access and manage document templates</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {TEMPLATES.map((template) => (
                      <TableRow key={template.id}>
                        <TableCell className="font-medium flex items-center gap-2">
                          <File className="h-4 w-4 text-muted-foreground" />
                          {template.name}
                        </TableCell>
                        <TableCell>{template.type}</TableCell>
                        <TableCell>{template.createdBy}</TableCell>
                        <TableCell>{format(template.createdDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{template.size}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Download</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Share className="h-4 w-4" />
                              <span className="sr-only">Share</span>
                            </Button>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Upload Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Upload Document</DialogTitle>
            <DialogDescription>Upload a new document to the system</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Document Type</label>
              <Select value={selectedDocType} onValueChange={setSelectedDocType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select document type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="treatment">Treatment Plan</SelectItem>
                  <SelectItem value="progress">Progress Report</SelectItem>
                  <SelectItem value="assessment">Assessment</SelectItem>
                  <SelectItem value="consent">Consent Form</SelectItem>
                  <SelectItem value="notes">Session Notes</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Client</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="alex">Alex Johnson</SelectItem>
                  <SelectItem value="maya">Maya Patel</SelectItem>
                  <SelectItem value="ethan">Ethan Williams</SelectItem>
                  <SelectItem value="sophia">Sophia Garcia</SelectItem>
                  <SelectItem value="noah">Noah Chen</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Document Status</label>
              <Select defaultValue="final">
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="final">Final</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
              <Upload className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm font-medium mb-1">Drag and drop file here</p>
              <p className="text-xs text-muted-foreground mb-4">or</p>
              <Button variant="outline" size="sm">
                Browse Files
              </Button>
              <p className="text-xs text-muted-foreground mt-4">
                Supported formats: PDF, DOCX, DOC, XLSX, JPG, PNG (Max 10MB)
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsUploadDialogOpen(false)}>Upload</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

