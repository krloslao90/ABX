import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Plus, Search } from "lucide-react"

export default function ClientsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Main Content */}
      <main className="flex-1 container p-6">
        <div className="flex items-center mb-6">
          <h2 className="text-3xl font-bold tracking-tight">Clients</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search clients..." className="w-[250px] pl-8" />
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Client
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="mb-6">
          <TabsList>
            <TabsTrigger value="all">All Clients</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="onhold">On Hold</TabsTrigger>
            <TabsTrigger value="new">New</TabsTrigger>
          </TabsList>
        </Tabs>

        <Card>
          <CardHeader>
            <CardTitle>Client Directory</CardTitle>
            <CardDescription>Manage and view all your client information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {[
                {
                  name: "Alex Johnson",
                  age: 6,
                  status: "Active",
                  therapist: "Dr. Sarah Miller",
                  nextSession: "Today, 9:00 AM",
                },
                {
                  name: "Maya Patel",
                  age: 8,
                  status: "Active",
                  therapist: "Thomas Wilson",
                  nextSession: "Today, 10:30 AM",
                },
                {
                  name: "Ethan Williams",
                  age: 5,
                  status: "On Hold",
                  therapist: "Jessica Taylor",
                  nextSession: "Tomorrow, 2:30 PM",
                },
                {
                  name: "Sophia Garcia",
                  age: 7,
                  status: "Active",
                  therapist: "Thomas Wilson",
                  nextSession: "Today, 4:00 PM",
                },
                {
                  name: "Noah Chen",
                  age: 4,
                  status: "New",
                  therapist: "Dr. Sarah Miller",
                  nextSession: "Today, 1:00 PM",
                },
                {
                  name: "Olivia Brown",
                  age: 6,
                  status: "Active",
                  therapist: "Jessica Taylor",
                  nextSession: "Tomorrow, 11:00 AM",
                },
                {
                  name: "Liam Davis",
                  age: 9,
                  status: "Active",
                  therapist: "Dr. Sarah Miller",
                  nextSession: "Friday, 3:30 PM",
                },
                { name: "Emma Wilson", age: 5, status: "On Hold", therapist: "Thomas Wilson", nextSession: "Pending" },
                {
                  name: "Aiden Martinez",
                  age: 7,
                  status: "Active",
                  therapist: "Jessica Taylor",
                  nextSession: "Thursday, 2:00 PM",
                },
                {
                  name: "Isabella Taylor",
                  age: 4,
                  status: "New",
                  therapist: "Dr. Sarah Miller",
                  nextSession: "Monday, 10:00 AM",
                },
              ].map((client, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>
                        {client.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{client.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Age: {client.age} • {client.therapist}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm font-medium">Next Session</p>
                      <p className="text-sm text-muted-foreground">{client.nextSession}</p>
                    </div>
                    <Badge
                      variant={
                        client.status === "Active" ? "default" : client.status === "On Hold" ? "secondary" : "outline"
                      }
                    >
                      {client.status}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

