"use client"

import { Textarea } from "@/components/ui/textarea"

import { Input } from "@/components/ui/input"

import { FormLabel } from "@/components/ui/form"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  ChevronLeft,
  MoreHorizontal,
  Calendar,
  FileText,
  CreditCard,
  MessageSquare,
  Edit,
  Download,
  Printer,
  Mail,
  Phone,
  MapPin,
  Clock,
  AlertCircle,
  CheckCircle2,
  Plus,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock client data
const CLIENT = {
  id: "1",
  name: "Alex Johnson",
  age: 6,
  dob: new Date(2019, 2, 15),
  status: "Active",
  avatar: "/placeholder.svg?height=128&width=128",
  parentName: "Sarah Johnson",
  email: "sarah.johnson@example.com",
  phone: "(555) 123-4567",
  address: "123 Main Street, Anytown, CA 94123",
  insuranceProvider: "Blue Cross Blue Shield",
  policyNumber: "BCBS-123456789",
  primaryTherapist: "Dr. Sarah Miller",
  secondaryTherapist: "Thomas Wilson",
  startDate: new Date(2023, 8, 10),
  diagnosis: "Autism Spectrum Disorder (Level 1)",
  allergies: "None",
  emergencyContact: "Michael Johnson (Father) - (555) 987-6543",
  notes:
    "Alex responds well to positive reinforcement and visual schedules. Prefers structured activities with clear expectations.",
}

// Mock treatment plan data
const TREATMENT_PLAN = {
  lastUpdated: new Date(2023, 11, 15),
  nextReview: new Date(2024, 2, 15),
  goals: [
    {
      id: 1,
      area: "Communication",
      description: "Increase verbal requests for preferred items",
      targetDate: new Date(2024, 5, 1),
      progress: 65,
      status: "In Progress",
    },
    {
      id: 2,
      area: "Social Skills",
      description: "Engage in cooperative play with peers for 10 minutes",
      targetDate: new Date(2024, 6, 15),
      progress: 40,
      status: "In Progress",
    },
    {
      id: 3,
      area: "Behavior",
      description: "Reduce instances of tantrum behavior during transitions",
      targetDate: new Date(2024, 4, 1),
      progress: 80,
      status: "In Progress",
    },
    {
      id: 4,
      area: "Self-Help",
      description: "Independently complete morning routine with visual schedule",
      targetDate: new Date(2024, 3, 15),
      progress: 90,
      status: "Near Completion",
    },
  ],
}

// Mock session data
const SESSIONS = [
  {
    id: 1,
    date: new Date(2024, 2, 10, 9, 0),
    duration: 60,
    therapist: "Dr. Sarah Miller",
    type: "Speech",
    status: "Completed",
    notes:
      "Worked on requesting preferred items using full sentences. Alex showed good progress with minimal prompting.",
  },
  {
    id: 2,
    date: new Date(2024, 2, 8, 10, 0),
    duration: 45,
    therapist: "Thomas Wilson",
    type: "Behavioral",
    status: "Completed",
    notes:
      "Focused on transition strategies. Used visual timer with success. Only one minor tantrum at the end of session.",
  },
  {
    id: 3,
    date: new Date(2024, 2, 6, 14, 0),
    duration: 60,
    therapist: "Dr. Sarah Miller",
    type: "Speech",
    status: "Completed",
    notes: "Practiced social greetings and turn-taking in conversation. Alex initiated greetings with minimal prompts.",
  },
  {
    id: 4,
    date: new Date(2024, 2, 3, 9, 0),
    duration: 60,
    therapist: "Dr. Sarah Miller",
    type: "Speech",
    status: "Completed",
    notes:
      "Worked on following 2-step instructions. Alex needed moderate prompting but showed improvement from last session.",
  },
  {
    id: 5,
    date: new Date(2024, 2, 1, 10, 0),
    duration: 45,
    therapist: "Thomas Wilson",
    type: "Behavioral",
    status: "Completed",
    notes: "Focused on self-regulation techniques. Introduced deep breathing with visual supports. Alex was receptive.",
  },
]

// Mock billing data
const BILLING = [
  {
    id: 1,
    date: new Date(2024, 2, 15),
    description: "Speech Therapy Sessions (5)",
    amount: 750.0,
    status: "Pending Insurance",
    invoice: "INV-2024-0315",
  },
  {
    id: 2,
    date: new Date(2024, 1, 15),
    description: "Speech & Behavioral Therapy Sessions (8)",
    amount: 1200.0,
    status: "Paid",
    invoice: "INV-2024-0215",
  },
  {
    id: 3,
    date: new Date(2024, 0, 15),
    description: "Speech & Behavioral Therapy Sessions (7)",
    amount: 1050.0,
    status: "Paid",
    invoice: "INV-2024-0115",
  },
  {
    id: 4,
    date: new Date(2023, 11, 15),
    description: "Speech Therapy Sessions (4)",
    amount: 600.0,
    status: "Paid",
    invoice: "INV-2023-1215",
  },
]

// Mock communication log
const COMMUNICATIONS = [
  {
    id: 1,
    date: new Date(2024, 2, 12, 15, 30),
    type: "Email",
    from: "Dr. Sarah Miller",
    to: "Sarah Johnson",
    subject: "Progress Update - Alex Johnson",
    content:
      "Hi Sarah, I wanted to update you on Alex's progress with his communication goals. He's showing great improvement in using full sentences for requests. We'll continue to work on this in our next session.",
  },
  {
    id: 2,
    date: new Date(2024, 2, 8, 10, 45),
    type: "Phone",
    from: "Thomas Wilson",
    to: "Sarah Johnson",
    subject: "Session Rescheduling",
    content:
      "Called to reschedule next week's behavioral therapy session from Tuesday to Wednesday at the same time. Parent confirmed the change.",
  },
  {
    id: 3,
    date: new Date(2024, 2, 5, 9, 15),
    type: "In Person",
    from: "Sarah Johnson",
    to: "Dr. Sarah Miller",
    subject: "Home Strategy Discussion",
    content:
      "Parent requested additional strategies for implementing communication practice at home. Provided visual supports and recommended specific activities.",
  },
  {
    id: 4,
    date: new Date(2024, 1, 28, 16, 0),
    type: "Email",
    from: "Billing Department",
    to: "Sarah Johnson",
    subject: "February Invoice",
    content:
      "Monthly invoice sent for February services. Included breakdown of insurance coverage and parent responsibility.",
  },
]

export default function ClientProfile({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [isAddNoteDialogOpen, setIsAddNoteDialogOpen] = useState(false)

  // Calculate client age
  const getAge = (birthDate: Date) => {
    const today = new Date()
    let age = today.getFullYear() - birthDate.getFullYear()
    const m = today.getMonth() - birthDate.getMonth()
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    return age
  }

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/clients">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">{CLIENT.name}</h2>
          <div className="ml-auto flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <MoreHorizontal className="h-4 w-4 mr-2" />
                  Actions
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Client Actions</DropdownMenuLabel>
                <DropdownMenuItem>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Client
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Session
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Download className="h-4 w-4 mr-2" />
                  Export Data
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Printer className="h-4 w-4 mr-2" />
                  Print Profile
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Client Info Card */}
          <Card className="md:col-span-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xl font-bold">Client Information</CardTitle>
              <Badge variant={CLIENT.status === "Active" ? "default" : "secondary"}>{CLIENT.status}</Badge>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="flex flex-col items-center mb-6">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={CLIENT.avatar} alt={CLIENT.name} />
                  <AvatarFallback>
                    {CLIENT.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-bold">{CLIENT.name}</h3>
                <p className="text-sm text-muted-foreground">
                  Age: {getAge(CLIENT.dob)} • DOB: {format(CLIENT.dob, "MM/dd/yyyy")}
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <Mail className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">{CLIENT.email}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <Phone className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Phone</p>
                    <p className="text-sm text-muted-foreground">{CLIENT.phone}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Address</p>
                    <p className="text-sm text-muted-foreground">{CLIENT.address}</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-sm font-medium">Parent/Guardian</p>
                  <p className="text-sm text-muted-foreground">{CLIENT.parentName}</p>
                </div>

                <div>
                  <p className="text-sm font-medium">Insurance</p>
                  <p className="text-sm text-muted-foreground">{CLIENT.insuranceProvider}</p>
                  <p className="text-sm text-muted-foreground">Policy: {CLIENT.policyNumber}</p>
                </div>

                <div>
                  <p className="text-sm font-medium">Primary Therapist</p>
                  <p className="text-sm text-muted-foreground">{CLIENT.primaryTherapist}</p>
                </div>

                <div>
                  <p className="text-sm font-medium">Start Date</p>
                  <p className="text-sm text-muted-foreground">{format(CLIENT.startDate, "MMMM d, yyyy")}</p>
                </div>

                <Separator />

                <div>
                  <p className="text-sm font-medium">Diagnosis</p>
                  <p className="text-sm text-muted-foreground">{CLIENT.diagnosis}</p>
                </div>

                <div>
                  <p className="text-sm font-medium">Allergies</p>
                  <p className="text-sm text-muted-foreground">{CLIENT.allergies}</p>
                </div>

                <div>
                  <p className="text-sm font-medium">Emergency Contact</p>
                  <p className="text-sm text-muted-foreground">{CLIENT.emergencyContact}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Content Area */}
          <div className="md:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-5 mb-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="sessions">Sessions</TabsTrigger>
                <TabsTrigger value="treatment">Treatment Plan</TabsTrigger>
                <TabsTrigger value="billing">Billing</TabsTrigger>
                <TabsTrigger value="communication">Communication</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Client Summary</CardTitle>
                    <CardDescription>
                      Quick overview of {CLIENT.name}'s therapy progress and upcoming sessions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Notes</h4>
                      <p className="text-sm text-muted-foreground">{CLIENT.notes}</p>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-2">Upcoming Sessions</h4>
                      <div className="rounded-md border">
                        <div className="flex items-center p-4">
                          <div className="flex h-12 w-12 items-center justify-center rounded-md border bg-muted">
                            <Calendar className="h-6 w-6" />
                          </div>
                          <div className="ml-4 space-y-1">
                            <p className="text-sm font-medium">Speech Therapy</p>
                            <p className="text-sm text-muted-foreground">Tomorrow, 9:00 AM • Dr. Sarah Miller</p>
                          </div>
                          <div className="ml-auto">
                            <Button variant="ghost" size="sm">
                              Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-2">Recent Progress</h4>
                      <div className="space-y-4">
                        {TREATMENT_PLAN.goals.slice(0, 2).map((goal) => (
                          <div key={goal.id} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium">
                                {goal.area}: {goal.description}
                              </p>
                              <span className="text-sm text-muted-foreground">{goal.progress}%</span>
                            </div>
                            <Progress value={goal.progress} className="h-2" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full" onClick={() => setActiveTab("treatment")}>
                      View Full Treatment Plan
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Latest sessions and communications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-8">
                      {SESSIONS.slice(0, 2).map((session) => (
                        <div key={session.id} className="flex">
                          <div className="relative mr-4">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full border bg-muted">
                              <FileText className="h-5 w-5" />
                            </div>
                            <span className="absolute top-0 right-0 flex h-3 w-3 rounded-full bg-green-500"></span>
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium">{session.type} Session</p>
                              <span className="text-xs text-muted-foreground">
                                {format(session.date, "MMM d, yyyy")}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {session.therapist} • {session.duration} minutes
                            </p>
                            <p className="text-sm">{session.notes}</p>
                          </div>
                        </div>
                      ))}

                      {COMMUNICATIONS.slice(0, 2).map((comm) => (
                        <div key={comm.id} className="flex">
                          <div className="relative mr-4">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full border bg-muted">
                              <MessageSquare className="h-5 w-5" />
                            </div>
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium">
                                {comm.type}: {comm.subject}
                              </p>
                              <span className="text-xs text-muted-foreground">{format(comm.date, "MMM d, yyyy")}</span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {comm.from} to {comm.to}
                            </p>
                            <p className="text-sm">{comm.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Sessions Tab */}
              <TabsContent value="sessions" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div>
                      <CardTitle>Session History</CardTitle>
                      <CardDescription>Record of all therapy sessions and notes</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button onClick={() => setIsAddNoteDialogOpen(true)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Session Note
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Therapist</TableHead>
                          <TableHead>Duration</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {SESSIONS.map((session) => (
                          <TableRow key={session.id}>
                            <TableCell>
                              <div className="font-medium">{format(session.date, "MMM d, yyyy")}</div>
                              <div className="text-xs text-muted-foreground">{format(session.date, "h:mm a")}</div>
                            </TableCell>
                            <TableCell>{session.type}</TableCell>
                            <TableCell>{session.therapist}</TableCell>
                            <TableCell>{session.duration} min</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                {session.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm">
                                View Notes
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Session Details</CardTitle>
                    <CardDescription>Select a session above to view detailed notes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center p-6 text-center text-muted-foreground">
                      <div>
                        <FileText className="mx-auto h-10 w-10 mb-3" />
                        <h3 className="text-lg font-medium">No Session Selected</h3>
                        <p className="text-sm">Click on "View Notes" for any session to see detailed information</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Treatment Plan Tab */}
              <TabsContent value="treatment" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div>
                      <CardTitle>Treatment Plan</CardTitle>
                      <CardDescription>
                        Last updated: {format(TREATMENT_PLAN.lastUpdated, "MMMM d, yyyy")} • Next review:{" "}
                        {format(TREATMENT_PLAN.nextReview, "MMMM d, yyyy")}
                      </CardDescription>
                    </div>
                    <Button variant="outline">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Plan
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {TREATMENT_PLAN.goals.map((goal) => (
                        <div key={goal.id} className="space-y-2">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="text-sm font-medium">{goal.area}</h4>
                              <p className="text-sm">{goal.description}</p>
                            </div>
                            <Badge
                              variant={goal.progress >= 90 ? "default" : goal.progress >= 50 ? "secondary" : "outline"}
                            >
                              {goal.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Progress value={goal.progress} className="h-2 flex-1" />
                            <span className="text-sm font-medium">{goal.progress}%</span>
                          </div>
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Target Date: {format(goal.targetDate, "MMMM d, yyyy")}</span>
                            <div className="flex items-center gap-1">
                              {goal.progress >= 75 ? (
                                <CheckCircle2 className="h-3 w-3 text-green-500" />
                              ) : (
                                <Clock className="h-3 w-3" />
                              )}
                              <span>{goal.progress >= 75 ? "On Track" : "In Progress"}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Intervention Strategies</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                          <span>Visual schedules for daily routines and transitions</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                          <span>Token economy system for positive reinforcement</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                          <span>Social stories for preparing for new situations</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                          <span>Structured play activities to promote peer interaction</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                          <span>Visual supports for communication</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Home Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                          <span>Implement consistent visual schedule at home</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                          <span>Practice communication strategies during daily routines</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                          <span>Use positive reinforcement consistently</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                          <span>Provide opportunities for social interaction with peers</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                          <span>Practice self-help skills with minimal prompting</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Billing Tab */}
              <TabsContent value="billing" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Billing History</CardTitle>
                    <CardDescription>Record of all invoices and payments</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Invoice</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {BILLING.map((bill) => (
                          <TableRow key={bill.id}>
                            <TableCell>{format(bill.date, "MMM d, yyyy")}</TableCell>
                            <TableCell>{bill.invoice}</TableCell>
                            <TableCell>{bill.description}</TableCell>
                            <TableCell>${bill.amount.toFixed(2)}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  bill.status === "Paid"
                                    ? "outline"
                                    : bill.status === "Pending Insurance"
                                      ? "secondary"
                                      : "destructive"
                                }
                                className={
                                  bill.status === "Paid"
                                    ? "bg-green-50 text-green-700 border-green-200"
                                    : bill.status === "Pending Insurance"
                                      ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                      : ""
                                }
                              >
                                {bill.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm">
                                <Download className="h-4 w-4 mr-2" />
                                Invoice
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Insurance Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm font-medium">Provider</p>
                          <p className="text-sm">{CLIENT.insuranceProvider}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Policy Number</p>
                          <p className="text-sm">{CLIENT.policyNumber}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Group Number</p>
                          <p className="text-sm">GRP-987654</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Coverage</p>
                          <p className="text-sm">80% after deductible for ABA therapy</p>
                          <p className="text-sm">$25 copay for speech therapy</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Authorization</p>
                          <p className="text-sm">Current authorization: 20 hours/month</p>
                          <p className="text-sm">Expires: June 30, 2024</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Billing Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <p className="text-sm font-medium">Year to Date Billed</p>
                          <p className="text-sm">$3,600.00</p>
                        </div>
                        <div className="flex justify-between">
                          <p className="text-sm font-medium">Insurance Paid</p>
                          <p className="text-sm">$2,280.00</p>
                        </div>
                        <div className="flex justify-between">
                          <p className="text-sm font-medium">Patient Responsibility</p>
                          <p className="text-sm">$570.00</p>
                        </div>
                        <div className="flex justify-between">
                          <p className="text-sm font-medium">Pending Insurance</p>
                          <p className="text-sm">$750.00</p>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-medium">
                          <p>Current Balance Due</p>
                          <p>$0.00</p>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" className="w-full">
                        <CreditCard className="h-4 w-4 mr-2" />
                        Make Payment
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>

              {/* Communication Tab */}
              <TabsContent value="communication" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div>
                      <CardTitle>Communication Log</CardTitle>
                      <CardDescription>Record of all communications with client and family</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button>
                        <MessageSquare className="h-4 w-4 mr-2" />
                        New Message
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {COMMUNICATIONS.map((comm) => (
                        <div key={comm.id} className="flex">
                          <div className="relative mr-4">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full border bg-muted">
                              {comm.type === "Email" ? (
                                <Mail className="h-5 w-5" />
                              ) : comm.type === "Phone" ? (
                                <Phone className="h-5 w-5" />
                              ) : (
                                <MessageSquare className="h-5 w-5" />
                              )}
                            </div>
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium">{comm.subject}</p>
                              <span className="text-xs text-muted-foreground">
                                {format(comm.date, "MMM d, yyyy")} at {format(comm.date, "h:mm a")}
                              </span>
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Badge variant="outline" className="mr-2">
                                {comm.type}
                              </Badge>
                              {comm.from} to {comm.to}
                            </div>
                            <p className="text-sm mt-2">{comm.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Contact Preferences</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium">Preferred Contact Method</p>
                        <p className="text-sm">Email</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Best Time to Call</p>
                        <p className="text-sm">Weekdays, 3:00 PM - 6:00 PM</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Communication Notes</p>
                        <p className="text-sm">
                          Parent prefers detailed session summaries via email. Phone calls for urgent matters only.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      {/* Add Session Note Dialog */}
      <Dialog open={isAddNoteDialogOpen} onOpenChange={setIsAddNoteDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Session Note</DialogTitle>
            <DialogDescription>Record details about a therapy session for {CLIENT.name}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Date</FormLabel>
              <div className="col-span-3">
                <Input type="date" defaultValue={format(new Date(), "yyyy-MM-dd")} />
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Time</FormLabel>
              <div className="col-span-3">
                <Input type="time" defaultValue="09:00" />
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Duration</FormLabel>
              <div className="col-span-3">
                <Input type="number" defaultValue="60" min="15" step="15" />
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Session Type</FormLabel>
              <div className="col-span-3">
                <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                  <option>Speech</option>
                  <option>Behavioral</option>
                  <option>Occupational</option>
                  <option>Assessment</option>
                  <option>Parent Training</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <FormLabel className="text-right">Therapist</FormLabel>
              <div className="col-span-3">
                <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                  <option>Dr. Sarah Miller</option>
                  <option>Thomas Wilson</option>
                  <option>Jessica Taylor</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <FormLabel className="text-right pt-2">Session Notes</FormLabel>
              <div className="col-span-3">
                <Textarea
                  placeholder="Enter detailed notes about the session, including activities, progress, and observations."
                  className="min-h-[100px]"
                />
              </div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <FormLabel className="text-right pt-2">Goals Addressed</FormLabel>
              <div className="col-span-3 space-y-2">
                {TREATMENT_PLAN.goals.map((goal) => (
                  <div key={goal.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`goal-${goal.id}`}
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                    />
                    <label htmlFor={`goal-${goal.id}`} className="text-sm">
                      {goal.area}: {goal.description}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddNoteDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsAddNoteDialogOpen(false)}>Save Session Note</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

