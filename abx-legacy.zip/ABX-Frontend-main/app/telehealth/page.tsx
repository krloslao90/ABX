"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  ChevronLeft,
  Video,
  Calendar,
  Clock,
  Users,
  Mic,
  MicOff,
  VideoOff,
  Phone,
  MessageSquare,
  Share,
  Settings,
  FileText,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock upcoming telehealth sessions
const UPCOMING_SESSIONS = [
  {
    id: 1,
    client: "Alex Johnson",
    therapist: "Dr. Sarah Miller",
    date: new Date(2024, 2, 16, 9, 0),
    duration: 60,
    type: "Speech Therapy",
    status: "Scheduled",
  },
  {
    id: 2,
    client: "Maya Patel",
    therapist: "Thomas Wilson",
    date: new Date(2024, 2, 16, 11, 0),
    duration: 45,
    type: "Behavioral Therapy",
    status: "Scheduled",
  },
  {
    id: 3,
    client: "Ethan Williams",
    therapist: "Jessica Taylor",
    date: new Date(2024, 2, 17, 14, 0),
    duration: 60,
    type: "Occupational Therapy",
    status: "Scheduled",
  },
]

// Mock past telehealth sessions
const PAST_SESSIONS = [
  {
    id: 4,
    client: "Alex Johnson",
    therapist: "Dr. Sarah Miller",
    date: new Date(2024, 2, 9, 9, 0),
    duration: 60,
    type: "Speech Therapy",
    status: "Completed",
    recording: true,
  },
  {
    id: 5,
    client: "Maya Patel",
    therapist: "Thomas Wilson",
    date: new Date(2024, 2, 7, 11, 0),
    duration: 45,
    type: "Behavioral Therapy",
    status: "Completed",
    recording: true,
  },
  {
    id: 6,
    client: "Sophia Garcia",
    therapist: "Thomas Wilson",
    date: new Date(2024, 2, 2, 15, 0),
    duration: 45,
    type: "Behavioral Therapy",
    status: "Completed",
    recording: false,
  },
]

export default function TelehealthPage() {
  const [activeTab, setActiveTab] = useState("upcoming")
  const [isSessionActive, setIsSessionActive] = useState(false)
  const [isVideoEnabled, setIsVideoEnabled] = useState(true)
  const [isAudioEnabled, setIsAudioEnabled] = useState(true)
  const [isNotesDialogOpen, setIsNotesDialogOpen] = useState(false)

  return (
    <div className="flex min-h-screen flex-col">     

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Telehealth</h2>
          <div className="ml-auto flex items-center gap-2">
            <Button>
              <Video className="mr-2 h-4 w-4" />
              New Session
            </Button>
          </div>
        </div>

        {isSessionActive ? (
          <div className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Active Session: Speech Therapy with Alex Johnson</CardTitle>
                  <CardDescription>Started at {format(new Date(), "h:mm a")} • Duration: 60 minutes</CardDescription>
                </div>
                <Badge className="bg-red-100 text-red-800 border-red-200">Live</Badge>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-2">
                    <div className="aspect-video bg-black rounded-lg flex items-center justify-center relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Avatar className="h-32 w-32">
                          <AvatarImage src="/placeholder.svg?height=128&width=128" alt="Alex Johnson" />
                          <AvatarFallback>AJ</AvatarFallback>
                        </Avatar>
                      </div>
                      <div className="absolute bottom-4 right-4 w-32 h-24 bg-gray-800 rounded-lg flex items-center justify-center">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback>AD</AvatarFallback>
                        </Avatar>
                      </div>
                      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
                        <Button
                          variant={isAudioEnabled ? "outline" : "destructive"}
                          size="icon"
                          className="bg-gray-800 hover:bg-gray-700 border-gray-700"
                          onClick={() => setIsAudioEnabled(!isAudioEnabled)}
                        >
                          {isAudioEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="destructive"
                          size="icon"
                          className="bg-red-600 hover:bg-red-700"
                          onClick={() => setIsSessionActive(false)}
                        >
                          <Phone className="h-4 w-4" />
                        </Button>
                        <Button
                          variant={isVideoEnabled ? "outline" : "destructive"}
                          size="icon"
                          className="bg-gray-800 hover:bg-gray-700 border-gray-700"
                          onClick={() => setIsVideoEnabled(!isVideoEnabled)}
                        >
                          {isVideoEnabled ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Session Information</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <Users className="h-4 w-4 mt-0.5 text-muted-foreground" />
                            <div>
                              <p className="text-sm font-medium">Client</p>
                              <p className="text-sm">Alex Johnson</p>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <Calendar className="h-4 w-4 mt-0.5 text-muted-foreground" />
                            <div>
                              <p className="text-sm font-medium">Date</p>
                              <p className="text-sm">{format(new Date(), "MMMM d, yyyy")}</p>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <Clock className="h-4 w-4 mt-0.5 text-muted-foreground" />
                            <div>
                              <p className="text-sm font-medium">Time</p>
                              <p className="text-sm">
                                {format(new Date(), "h:mm a")} -{" "}
                                {format(new Date(new Date().getTime() + 60 * 60 * 1000), "h:mm a")}
                              </p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <div className="flex flex-col gap-2">
                      <Button variant="outline" className="justify-start">
                        <Share className="mr-2 h-4 w-4" />
                        Share Screen
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <MessageSquare className="mr-2 h-4 w-4" />
                        Chat
                      </Button>
                      <Button variant="outline" className="justify-start" onClick={() => setIsNotesDialogOpen(true)}>
                        <FileText className="mr-2 h-4 w-4" />
                        Session Notes
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <Settings className="mr-2 h-4 w-4" />
                        Settings
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList>
              <TabsTrigger value="upcoming">Upcoming Sessions</TabsTrigger>
              <TabsTrigger value="past">Past Sessions</TabsTrigger>
            </TabsList>

            {/* Upcoming Sessions Tab */}
            <TabsContent value="upcoming">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {UPCOMING_SESSIONS.map((session) => (
                  <Card key={session.id}>
                    <CardHeader>
                      <CardTitle>{session.client}</CardTitle>
                      <CardDescription>{session.type}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-start gap-2">
                          <Calendar className="h-4 w-4 mt-0.5 text-muted-foreground" />
                          <div>
                            <p className="text-sm font-medium">Date</p>
                            <p className="text-sm">{format(session.date, "MMMM d, yyyy")}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <Clock className="h-4 w-4 mt-0.5 text-muted-foreground" />
                          <div>
                            <p className="text-sm font-medium">Time</p>
                            <p className="text-sm">
                              {format(session.date, "h:mm a")} -{" "}
                              {format(new Date(session.date.getTime() + session.duration * 60 * 1000), "h:mm a")}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <Users className="h-4 w-4 mt-0.5 text-muted-foreground" />
                          <div>
                            <p className="text-sm font-medium">Therapist</p>
                            <p className="text-sm">{session.therapist}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      {new Date(session.date).getTime() - new Date().getTime() < 15 * 60 * 1000 ? (
                        <Button className="w-full" onClick={() => setIsSessionActive(true)}>
                          <Video className="mr-2 h-4 w-4" />
                          Join Session
                        </Button>
                      ) : (
                        <Button variant="outline" className="w-full" disabled>
                          <Clock className="mr-2 h-4 w-4" />
                          Starts in{" "}
                          {Math.floor((new Date(session.date).getTime() - new Date().getTime()) / (60 * 60 * 1000))}{" "}
                          hours
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Past Sessions Tab */}
            <TabsContent value="past">
              <Card>
                <CardHeader>
                  <CardTitle>Past Sessions</CardTitle>
                  <CardDescription>View recordings and notes from previous telehealth sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {PAST_SESSIONS.map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-4 rounded-lg border">
                        <div className="flex items-center gap-4">
                          <div className="flex h-12 w-12 items-center justify-center rounded-md border bg-muted">
                            <Video className="h-6 w-6 text-muted-foreground" />
                          </div>
                          <div>
                            <p className="font-medium">
                              {session.client} - {session.type}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {format(session.date, "MMMM d, yyyy")} • {format(session.date, "h:mm a")} •{" "}
                              {session.therapist}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {session.recording && (
                            <Button variant="outline" size="sm">
                              <Video className="mr-2 h-4 w-4" />
                              Recording
                            </Button>
                          )}
                          <Button variant="outline" size="sm">
                            <FileText className="mr-2 h-4 w-4" />
                            Notes
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </main>

      {/* Session Notes Dialog */}
      <Dialog open={isNotesDialogOpen} onOpenChange={setIsNotesDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Session Notes</DialogTitle>
            <DialogDescription>Record notes for the current telehealth session</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-start gap-4">
              <label className="text-right text-sm font-medium pt-2">Session Notes</label>
              <Textarea
                className="col-span-3"
                placeholder="Enter detailed notes about the session, including activities, progress, and observations."
                rows={8}
              />
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <label className="text-right text-sm font-medium pt-2">Goals Addressed</label>
              <div className="col-span-3 space-y-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="goal-1"
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <label htmlFor="goal-1" className="text-sm">
                    Increase verbal requests for preferred items
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="goal-2"
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <label htmlFor="goal-2" className="text-sm">
                    Follow 2-step instructions
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="goal-3"
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <label htmlFor="goal-3" className="text-sm">
                    Engage in cooperative play with peers
                  </label>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <label className="text-right text-sm font-medium pt-2">Follow-up</label>
              <Input className="col-span-3" placeholder="Any follow-up actions needed" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNotesDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsNotesDialogOpen(false)}>Save Notes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

