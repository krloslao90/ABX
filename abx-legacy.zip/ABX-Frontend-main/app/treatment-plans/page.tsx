"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ChevronLeft, Search, Filter, Plus, FileText, Copy } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock treatment plan templates
const TEMPLATES = [
  {
    id: 1,
    name: "ASD Level 1 - Communication Focus",
    category: "Autism Spectrum",
    lastUpdated: new Date(2024, 1, 15),
    createdBy: "Dr. Sarah Miller",
    usageCount: 12,
  },
  {
    id: 2,
    name: "ASD Level 2 - Behavioral Focus",
    category: "Autism Spectrum",
    lastUpdated: new Date(2024, 0, 20),
    createdBy: "Thomas Wilson",
    usageCount: 8,
  },
  {
    id: 3,
    name: "ADHD - Executive Function",
    category: "ADHD",
    lastUpdated: new Date(2024, 2, 5),
    createdBy: "Jessica Taylor",
    usageCount: 5,
  },
  {
    id: 4,
    name: "Speech Delay - Articulation",
    category: "Speech",
    lastUpdated: new Date(2023, 11, 10),
    createdBy: "Dr. Sarah Miller",
    usageCount: 15,
  },
  {
    id: 5,
    name: "Fine Motor Skills Development",
    category: "Occupational",
    lastUpdated: new Date(2024, 1, 28),
    createdBy: "Jessica Taylor",
    usageCount: 7,
  },
]

// Mock active treatment plans
const ACTIVE_PLANS = [
  {
    id: 1,
    client: "Alex Johnson",
    planName: "ASD Level 1 - Communication Focus",
    startDate: new Date(2023, 8, 15),
    reviewDate: new Date(2024, 2, 15),
    therapist: "Dr. Sarah Miller",
    status: "Active",
  },
  {
    id: 2,
    client: "Maya Patel",
    planName: "ASD Level 2 - Behavioral Focus",
    startDate: new Date(2023, 10, 5),
    reviewDate: new Date(2024, 4, 5),
    therapist: "Thomas Wilson",
    status: "Active",
  },
  {
    id: 3,
    client: "Ethan Williams",
    planName: "Fine Motor Skills Development",
    startDate: new Date(2024, 0, 10),
    reviewDate: new Date(2024, 6, 10),
    therapist: "Jessica Taylor",
    status: "Active",
  },
  {
    id: 4,
    client: "Sophia Garcia",
    planName: "ADHD - Executive Function",
    startDate: new Date(2023, 9, 20),
    reviewDate: new Date(2024, 3, 20),
    therapist: "Thomas Wilson",
    status: "Under Review",
  },
  {
    id: 5,
    client: "Noah Chen",
    planName: "Speech Delay - Articulation",
    startDate: new Date(2024, 1, 15),
    reviewDate: new Date(2024, 7, 15),
    therapist: "Dr. Sarah Miller",
    status: "Active",
  },
]

export default function TreatmentPlansPage() {
  const [activeTab, setActiveTab] = useState("active")

  return (
    <div className="flex min-h-screen flex-col">     

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Treatment Plans</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search plans..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Plan
            </Button>
          </div>
        </div>

        <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="active">Active Plans</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="archived">Archived</TabsTrigger>
          </TabsList>

          {/* Active Plans Tab */}
          <TabsContent value="active">
            <Card>
              <CardHeader>
                <CardTitle>Active Treatment Plans</CardTitle>
                <CardDescription>View and manage all active client treatment plans</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Start Date</TableHead>
                      <TableHead>Next Review</TableHead>
                      <TableHead>Therapist</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ACTIVE_PLANS.map((plan) => (
                      <TableRow key={plan.id}>
                        <TableCell className="font-medium">{plan.client}</TableCell>
                        <TableCell>{plan.planName}</TableCell>
                        <TableCell>{format(plan.startDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{format(plan.reviewDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>{plan.therapist}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              plan.status === "Active"
                                ? "outline"
                                : plan.status === "Under Review"
                                  ? "secondary"
                                  : "destructive"
                            }
                            className={
                              plan.status === "Active"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : plan.status === "Under Review"
                                  ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                  : ""
                            }
                          >
                            {plan.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={`/clients/${plan.id}`}>View</Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates">
            <Card>
              <CardHeader>
                <CardTitle>Treatment Plan Templates</CardTitle>
                <CardDescription>Standardized templates for creating new treatment plans</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Template Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead>Usage Count</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {TEMPLATES.map((template) => (
                      <TableRow key={template.id}>
                        <TableCell className="font-medium">{template.name}</TableCell>
                        <TableCell>{template.category}</TableCell>
                        <TableCell>{format(template.lastUpdated, "MMM d, yyyy")}</TableCell>
                        <TableCell>{template.createdBy}</TableCell>
                        <TableCell>{template.usageCount}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Copy className="h-4 w-4 mr-1" />
                              Use
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Archived Tab */}
          <TabsContent value="archived">
            <Card>
              <CardHeader>
                <CardTitle>Archived Treatment Plans</CardTitle>
                <CardDescription>View historical treatment plans</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <FileText className="h-10 w-10 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No Archived Plans</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    There are no archived treatment plans at the moment.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

