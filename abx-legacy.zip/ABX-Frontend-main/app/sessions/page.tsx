"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import { ChevronLeft, Search, Filter, FileText, Plus, Calendar, CheckCircle2, Clock, AlertCircle } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock session data
const SESSIONS = [
  {
    id: 1,
    client: "Alex Johnson",
    date: new Date(2024, 2, 10, 9, 0),
    duration: 60,
    therapist: "Dr. Sarah Miller",
    type: "Speech",
    status: "Completed",
    notes:
      "Worked on requesting preferred items using full sentences. Alex showed good progress with minimal prompting.",
    goals: [
      { id: 1, description: "Increase verbal requests for preferred items", progress: 65 },
      { id: 2, description: "Follow 2-step instructions", progress: 80 },
    ],
  },
  {
    id: 2,
    client: "Maya Patel",
    date: new Date(2024, 2, 8, 10, 0),
    duration: 45,
    therapist: "Thomas Wilson",
    type: "Behavioral",
    status: "Completed",
    notes:
      "Focused on transition strategies. Used visual timer with success. Only one minor tantrum at the end of session.",
    goals: [
      { id: 3, description: "Reduce instances of tantrum behavior during transitions", progress: 70 },
      { id: 4, description: "Use calming strategies when frustrated", progress: 60 },
    ],
  },
  {
    id: 3,
    client: "Ethan Williams",
    date: new Date(2024, 2, 6, 14, 0),
    duration: 60,
    therapist: "Jessica Taylor",
    type: "Occupational",
    status: "Completed",
    notes:
      "Worked on fine motor skills through bead stringing and button activities. Ethan showed improved pincer grasp.",
    goals: [
      { id: 5, description: "Improve fine motor coordination", progress: 75 },
      { id: 6, description: "Complete self-care tasks independently", progress: 65 },
    ],
  },
  {
    id: 4,
    client: "Sophia Garcia",
    date: new Date(2024, 2, 3, 9, 0),
    duration: 60,
    therapist: "Thomas Wilson",
    type: "Behavioral",
    status: "Completed",
    notes:
      "Practiced social skills in group setting. Sophia initiated conversation with peers twice without prompting.",
    goals: [
      { id: 7, description: "Initiate peer interactions", progress: 55 },
      { id: 8, description: "Take turns in conversation", progress: 60 },
    ],
  },
  {
    id: 5,
    client: "Noah Chen",
    date: new Date(2024, 2, 1, 10, 0),
    duration: 90,
    therapist: "Dr. Sarah Miller",
    type: "Assessment",
    status: "Completed",
    notes:
      "Completed initial assessment. Noah showed strengths in receptive language and challenges with expressive language and social interaction.",
    goals: [
      { id: 9, description: "Develop baseline for communication skills", progress: 100 },
      { id: 10, description: "Identify priority treatment areas", progress: 100 },
    ],
  },
  {
    id: 6,
    client: "Alex Johnson",
    date: new Date(2024, 1, 28, 9, 0),
    duration: 60,
    therapist: "Dr. Sarah Miller",
    type: "Speech",
    status: "Completed",
    notes: "Continued work on verbal requests. Alex used full sentences for 8/10 requests with minimal prompting.",
    goals: [
      { id: 1, description: "Increase verbal requests for preferred items", progress: 60 },
      { id: 2, description: "Follow 2-step instructions", progress: 75 },
    ],
  },
  {
    id: 7,
    client: "Maya Patel",
    date: new Date(2024, 1, 26, 10, 0),
    duration: 45,
    therapist: "Thomas Wilson",
    type: "Behavioral",
    status: "Completed",
    notes: "Introduced visual schedule for transitions. Maya responded well to the visual supports.",
    goals: [
      { id: 3, description: "Reduce instances of tantrum behavior during transitions", progress: 65 },
      { id: 4, description: "Use calming strategies when frustrated", progress: 55 },
    ],
  },
  {
    id: 8,
    client: "Ethan Williams",
    date: new Date(2024, 1, 24, 14, 0),
    duration: 60,
    therapist: "Jessica Taylor",
    type: "Occupational",
    status: "Completed",
    notes:
      "Practiced buttoning and zipping. Ethan needed moderate assistance but showed improvement from last session.",
    goals: [
      { id: 5, description: "Improve fine motor coordination", progress: 70 },
      { id: 6, description: "Complete self-care tasks independently", progress: 60 },
    ],
  },
]

export default function SessionsPage() {
  const [selectedSession, setSelectedSession] = useState(SESSIONS[0])
  const [activeTab, setActiveTab] = useState("all")

  // Filter sessions based on active tab
  const filteredSessions =
    activeTab === "all" ? SESSIONS : SESSIONS.filter((session) => session.type.toLowerCase() === activeTab)

  return (
    <div className="flex min-h-screen flex-col">     

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Session Notes</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search sessions..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button asChild>
              <Link href="/calendar">
                <Calendar className="mr-2 h-4 w-4" />
                Schedule Session
              </Link>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="all">All Sessions</TabsTrigger>
            <TabsTrigger value="speech">Speech</TabsTrigger>
            <TabsTrigger value="behavioral">Behavioral</TabsTrigger>
            <TabsTrigger value="occupational">Occupational</TabsTrigger>
            <TabsTrigger value="assessment">Assessment</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Session List */}
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Recent Sessions</CardTitle>
              <CardDescription>Select a session to view details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {filteredSessions.map((session) => (
                  <div
                    key={session.id}
                    className={`p-3 rounded-md border cursor-pointer hover:bg-muted/50 ${
                      selectedSession.id === session.id ? "bg-muted border-primary" : ""
                    }`}
                    onClick={() => setSelectedSession(session)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{session.client}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(session.date, "MMM d, yyyy")} • {format(session.date, "h:mm a")}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          session.type === "Speech"
                            ? "bg-blue-50 text-blue-700 border-blue-200"
                            : session.type === "Behavioral"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : session.type === "Occupational"
                                ? "bg-purple-50 text-purple-700 border-purple-200"
                                : "bg-orange-50 text-orange-700 border-orange-200"
                        }
                      >
                        {session.type}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Session Details */}
          <Card className="md:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>
                  {selectedSession.client} - {selectedSession.type} Session
                </CardTitle>
                <CardDescription>
                  {format(selectedSession.date, "MMMM d, yyyy")} at {format(selectedSession.date, "h:mm a")} •{" "}
                  {selectedSession.duration} minutes
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" />
                  Print
                </Button>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Note
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Session Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium">Therapist</p>
                      <p className="text-sm">{selectedSession.therapist}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Session Type</p>
                      <p className="text-sm">{selectedSession.type}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Status</p>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {selectedSession.status}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Duration</p>
                      <p className="text-sm">{selectedSession.duration} minutes</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Session Notes</h3>
                  <div className="p-4 rounded-md border bg-muted/30">
                    <p className="text-sm">{selectedSession.notes}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Goals Addressed</h3>
                  <div className="space-y-4">
                    {selectedSession.goals.map((goal) => (
                      <div key={goal.id} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium">{goal.description}</p>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">{goal.progress}%</span>
                            {goal.progress >= 75 ? (
                              <CheckCircle2 className="h-4 w-4 text-green-500" />
                            ) : (
                              <Clock className="h-4 w-4 text-amber-500" />
                            )}
                          </div>
                        </div>
                        <Progress value={goal.progress} className="h-2" />
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Materials Used</h3>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    <li>Visual schedule cards</li>
                    <li>Communication picture cards</li>
                    <li>Token board for reinforcement</li>
                    <li>Social stories book</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Recommendations</h3>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                      <p className="text-sm">
                        Continue practicing requesting with full sentences during daily routines
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                      <p className="text-sm">Use visual timer for transitions at home</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                      <p className="text-sm">Practice following 2-step instructions during play activities</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Progress Tracking</CardTitle>
              <CardDescription>Track progress across sessions for {selectedSession.client}</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Goal</TableHead>
                    <TableHead>Baseline</TableHead>
                    <TableHead>Current</TableHead>
                    <TableHead>Target</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedSession.goals.map((goal) => (
                    <TableRow key={goal.id}>
                      <TableCell className="font-medium">{goal.description}</TableCell>
                      <TableCell>25%</TableCell>
                      <TableCell>{goal.progress}%</TableCell>
                      <TableCell>90%</TableCell>
                      <TableCell>
                        <Progress value={goal.progress} className="h-2 w-[100px]" />
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={goal.progress >= 90 ? "default" : goal.progress >= 50 ? "secondary" : "outline"}
                        >
                          {goal.progress >= 90 ? "Achieved" : goal.progress >= 50 ? "In Progress" : "Started"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

