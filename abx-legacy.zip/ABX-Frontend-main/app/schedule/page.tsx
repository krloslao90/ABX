import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, Plus } from "lucide-react"
import Link from "next/link"

export default function SchedulePage() {
  // Mock data for the current date
  const today = new Date()
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const currentDay = dayNames[today.getDay()]
  const currentDate = today.getDate()
  const currentMonth = monthNames[today.getMonth()]
  const currentYear = today.getFullYear()

  // Mock time slots
  const timeSlots = [
    "8:00 AM",
    "9:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "1:00 PM",
    "2:00 PM",
    "3:00 PM",
    "4:00 PM",
    "5:00 PM",
  ]

  // Mock sessions data
  const sessions = [
    { time: "9:00 AM", client: "Alex Johnson", therapist: "Dr. Sarah Miller", type: "Speech", duration: "60 min" },
    { time: "10:30 AM", client: "Maya Patel", therapist: "Thomas Wilson", type: "Behavioral", duration: "45 min" },
    {
      time: "1:00 PM",
      client: "Noah Chen",
      therapist: "Dr. Sarah Miller",
      type: "Initial Assessment",
      duration: "90 min",
    },
    {
      time: "2:30 PM",
      client: "Ethan Williams",
      therapist: "Jessica Taylor",
      type: "Occupational",
      duration: "60 min",
    },
    { time: "4:00 PM", client: "Sophia Garcia", therapist: "Thomas Wilson", type: "Behavioral", duration: "45 min" },
  ]

  // Helper function to check if a time slot has a session
  const getSessionForTimeSlot = (time) => {
    return sessions.find((session) => session.time === time)
  }

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Schedule</h2>
          <div className="ml-auto flex items-center gap-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by Therapist" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Therapists</SelectItem>
                <SelectItem value="sarah">Dr. Sarah Miller</SelectItem>
                <SelectItem value="thomas">Thomas Wilson</SelectItem>
                <SelectItem value="jessica">Jessica Taylor</SelectItem>
              </SelectContent>
            </Select>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Session
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center">
            <div>
              <CardTitle>Daily Schedule</CardTitle>
              <CardDescription>View and manage therapy sessions</CardDescription>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <Button variant="outline" size="icon">
                <ChevronLeft className="h-4 w-4" />
                <span className="sr-only">Previous Day</span>
              </Button>
              <div className="font-medium">
                {currentDay}, {currentMonth} {currentDate}, {currentYear}
              </div>
              <Button variant="outline" size="icon">
                <ChevronRight className="h-4 w-4" />
                <span className="sr-only">Next Day</span>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {timeSlots.map((time, i) => {
                const session = getSessionForTimeSlot(time)

                return (
                  <div key={i} className="grid grid-cols-[80px_1fr] gap-4">
                    <div className="py-2 text-sm font-medium text-muted-foreground">{time}</div>
                    {session ? (
                      <div className="rounded-md border border-l-4 border-l-primary p-3 hover:bg-muted/50">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{session.client}</p>
                            <p className="text-sm text-muted-foreground">
                              {session.therapist} • {session.type} • {session.duration}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{session.type}</Badge>
                            <Button variant="ghost" size="sm">
                              Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="rounded-md border border-dashed p-3 hover:bg-muted/50">
                        <p className="text-sm text-muted-foreground text-center">Available</p>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

