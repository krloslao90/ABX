"use client"

import { Textarea } from "@/components/ui/textarea"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  ChevronLeft,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
  FileText,
  Download,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock insurance verification data
const VERIFICATIONS = [
  {
    id: 1,
    client: "Alex Johnson",
    provider: "Blue Cross Blue Shield",
    policyNumber: "BCBS123456789",
    status: "Verified",
    verifiedDate: new Date(2024, 1, 15),
    expirationDate: new Date(2024, 7, 15),
    coverage: {
      aba: "80% after deductible",
      speech: "$25 copay per session",
      occupational: "80% after deductible",
      deductible: "$1,000 ($250 remaining)",
      authorizationRequired: true,
      authorizedHours: "20 hours/month",
      notes: "Prior authorization required for ABA therapy. Current authorization valid through 08/15/2024.",
    },
  },
  {
    id: 2,
    client: "Maya Patel",
    provider: "Aetna",
    policyNumber: "AET987654321",
    status: "Verified",
    verifiedDate: new Date(2024, 2, 1),
    expirationDate: new Date(2024, 8, 1),
    coverage: {
      aba: "90% after deductible",
      speech: "$30 copay per session",
      occupational: "90% after deductible",
      deductible: "$500 ($0 remaining)",
      authorizationRequired: true,
      authorizedHours: "15 hours/month",
      notes: "Deductible met for 2024. Authorization renewal needed by 09/01/2024.",
    },
  },
  {
    id: 3,
    client: "Ethan Williams",
    provider: "UnitedHealthcare",
    policyNumber: "UHC456789123",
    status: "Expiring Soon",
    verifiedDate: new Date(2023, 11, 10),
    expirationDate: new Date(2024, 3, 10),
    coverage: {
      aba: "70% after deductible",
      speech: "$40 copay per session",
      occupational: "70% after deductible",
      deductible: "$1,500 ($500 remaining)",
      authorizationRequired: true,
      authorizedHours: "10 hours/month",
      notes: "Authorization expires on 04/10/2024. Renewal process should begin by 03/10/2024.",
    },
  },
  {
    id: 4,
    client: "Sophia Garcia",
    provider: "Cigna",
    policyNumber: "CIG789123456",
    status: "Verification Needed",
    verifiedDate: null,
    expirationDate: null,
    coverage: null,
  },
  {
    id: 5,
    client: "Noah Chen",
    provider: "Humana",
    policyNumber: "HUM321654987",
    status: "In Progress",
    verifiedDate: null,
    expirationDate: null,
    coverage: null,
  },
]

// Mock authorization data
const AUTHORIZATIONS = [
  {
    id: 1,
    client: "Alex Johnson",
    provider: "Blue Cross Blue Shield",
    type: "ABA Therapy",
    authorizedHours: 20,
    startDate: new Date(2024, 1, 15),
    endDate: new Date(2024, 7, 15),
    status: "Active",
    authNumber: "AUTH-12345-BCBS",
  },
  {
    id: 2,
    client: "Alex Johnson",
    provider: "Blue Cross Blue Shield",
    type: "Speech Therapy",
    authorizedHours: 8,
    startDate: new Date(2024, 1, 15),
    endDate: new Date(2024, 7, 15),
    status: "Active",
    authNumber: "AUTH-12346-BCBS",
  },
  {
    id: 3,
    client: "Maya Patel",
    provider: "Aetna",
    type: "ABA Therapy",
    authorizedHours: 15,
    startDate: new Date(2024, 2, 1),
    endDate: new Date(2024, 8, 1),
    status: "Active",
    authNumber: "AUTH-54321-AET",
  },
  {
    id: 4,
    client: "Ethan Williams",
    provider: "UnitedHealthcare",
    type: "ABA Therapy",
    authorizedHours: 10,
    startDate: new Date(2023, 11, 10),
    endDate: new Date(2024, 3, 10),
    status: "Expiring Soon",
    authNumber: "AUTH-67890-UHC",
  },
  {
    id: 5,
    client: "Ethan Williams",
    provider: "UnitedHealthcare",
    type: "Occupational Therapy",
    authorizedHours: 8,
    startDate: new Date(2023, 11, 10),
    endDate: new Date(2024, 3, 10),
    status: "Expiring Soon",
    authNumber: "AUTH-67891-UHC",
  },
]

export default function InsurancePage() {
  const [activeTab, setActiveTab] = useState("verification")
  const [selectedVerification, setSelectedVerification] = useState(VERIFICATIONS[0])
  const [isVerificationDialogOpen, setIsVerificationDialogOpen] = useState(false)
  const [isAuthDialogOpen, setIsAuthDialogOpen] = useState(false)

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Insurance Management</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search client or policy..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button onClick={() => setIsVerificationDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              New Verification
            </Button>
          </div>
        </div>

        <Tabs defaultValue="verification" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="verification">Verifications</TabsTrigger>
            <TabsTrigger value="authorizations">Authorizations</TabsTrigger>
            <TabsTrigger value="claims">Claims</TabsTrigger>
          </TabsList>

          {/* Verifications Tab */}
          <TabsContent value="verification">
            <Card>
              <CardHeader>
                <CardTitle>Insurance Verifications</CardTitle>
                <CardDescription>Manage and track client insurance verifications</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client</TableHead>
                      <TableHead>Insurance Provider</TableHead>
                      <TableHead>Policy Number</TableHead>
                      <TableHead>Verified Date</TableHead>
                      <TableHead>Expiration</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {VERIFICATIONS.map((verification) => (
                      <TableRow key={verification.id}>
                        <TableCell className="font-medium">{verification.client}</TableCell>
                        <TableCell>{verification.provider}</TableCell>
                        <TableCell>{verification.policyNumber}</TableCell>
                        <TableCell>
                          {verification.verifiedDate ? format(verification.verifiedDate, "MMM d, yyyy") : "-"}
                        </TableCell>
                        <TableCell>
                          {verification.expirationDate ? format(verification.expirationDate, "MMM d, yyyy") : "-"}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              verification.status === "Verified"
                                ? "outline"
                                : verification.status === "Expiring Soon"
                                  ? "secondary"
                                  : verification.status === "In Progress"
                                    ? "default"
                                    : "destructive"
                            }
                            className={
                              verification.status === "Verified"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : verification.status === "Expiring Soon"
                                  ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                  : verification.status === "In Progress"
                                    ? "bg-blue-50 text-blue-700 border-blue-200"
                                    : "bg-red-50 text-red-700 border-red-200"
                            }
                          >
                            <div className="flex items-center gap-1">
                              {verification.status === "Verified" && <CheckCircle2 className="h-3.5 w-3.5" />}
                              {verification.status === "Expiring Soon" && <Clock className="h-3.5 w-3.5" />}
                              {verification.status === "In Progress" && <RefreshCw className="h-3.5 w-3.5" />}
                              {verification.status === "Verification Needed" && <AlertCircle className="h-3.5 w-3.5" />}
                              <span>{verification.status}</span>
                            </div>
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedVerification(verification)
                              setIsVerificationDialogOpen(true)
                            }}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Authorizations Tab */}
          <TabsContent value="authorizations">
            <Card>
              <CardHeader>
                <CardTitle>Service Authorizations</CardTitle>
                <CardDescription>Track and manage insurance authorizations for therapy services</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client</TableHead>
                      <TableHead>Provider</TableHead>
                      <TableHead>Service Type</TableHead>
                      <TableHead>Auth Number</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead>Valid Period</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {AUTHORIZATIONS.map((auth) => (
                      <TableRow key={auth.id}>
                        <TableCell className="font-medium">{auth.client}</TableCell>
                        <TableCell>{auth.provider}</TableCell>
                        <TableCell>{auth.type}</TableCell>
                        <TableCell>{auth.authNumber}</TableCell>
                        <TableCell>{auth.authorizedHours} hrs/month</TableCell>
                        <TableCell>
                          {format(auth.startDate, "MM/dd/yyyy")} - {format(auth.endDate, "MM/dd/yyyy")}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              auth.status === "Active"
                                ? "outline"
                                : auth.status === "Expiring Soon"
                                  ? "secondary"
                                  : "destructive"
                            }
                            className={
                              auth.status === "Active"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : auth.status === "Expiring Soon"
                                  ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                  : "bg-red-50 text-red-700 border-red-200"
                            }
                          >
                            <div className="flex items-center gap-1">
                              {auth.status === "Active" && <CheckCircle2 className="h-3.5 w-3.5" />}
                              {auth.status === "Expiring Soon" && <Clock className="h-3.5 w-3.5" />}
                              <span>{auth.status}</span>
                            </div>
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => setIsAuthDialogOpen(true)}>
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="ml-auto" onClick={() => setIsAuthDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  New Authorization
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          {/* Claims Tab */}
          <TabsContent value="claims">
            <Card>
              <CardHeader>
                <CardTitle>Insurance Claims</CardTitle>
                <CardDescription>Track and manage insurance claims</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <FileText className="h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">Claims Management</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    This feature is coming soon. You'll be able to track and manage insurance claims.
                  </p>
                  <Button disabled>Coming Soon</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Verification Dialog */}
      <Dialog open={isVerificationDialogOpen} onOpenChange={setIsVerificationDialogOpen}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>
              {selectedVerification?.status === "Verified" || selectedVerification?.status === "Expiring Soon"
                ? `Insurance Verification: ${selectedVerification?.client}`
                : "New Insurance Verification"}
            </DialogTitle>
            <DialogDescription>
              {selectedVerification?.status === "Verified" || selectedVerification?.status === "Expiring Soon"
                ? `View or update insurance verification details`
                : "Verify a client's insurance coverage"}
            </DialogDescription>
          </DialogHeader>

          {selectedVerification?.status === "Verified" || selectedVerification?.status === "Expiring Soon" ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Client Information</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Client:</span>
                      <span className="text-sm font-medium">{selectedVerification.client}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Insurance Provider:</span>
                      <span className="text-sm font-medium">{selectedVerification.provider}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Policy Number:</span>
                      <span className="text-sm font-medium">{selectedVerification.policyNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Verified Date:</span>
                      <span className="text-sm font-medium">
                        {format(selectedVerification.verifiedDate, "MMMM d, yyyy")}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Expiration Date:</span>
                      <span className="text-sm font-medium">
                        {format(selectedVerification.expirationDate, "MMMM d, yyyy")}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">Coverage Details</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">ABA Therapy:</span>
                      <span className="text-sm font-medium">{selectedVerification.coverage.aba}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Speech Therapy:</span>
                      <span className="text-sm font-medium">{selectedVerification.coverage.speech}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Occupational Therapy:</span>
                      <span className="text-sm font-medium">{selectedVerification.coverage.occupational}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Deductible:</span>
                      <span className="text-sm font-medium">{selectedVerification.coverage.deductible}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Authorization Required:</span>
                      <span className="text-sm font-medium">
                        {selectedVerification.coverage.authorizationRequired ? "Yes" : "No"}
                      </span>
                    </div>
                    {selectedVerification.coverage.authorizationRequired && (
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Authorized Hours:</span>
                        <span className="text-sm font-medium">{selectedVerification.coverage.authorizedHours}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Notes</h3>
                <p className="text-sm p-3 bg-muted rounded-md">{selectedVerification.coverage.notes}</p>
              </div>

              <div className="flex justify-between">
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsVerificationDialogOpen(false)}>
                    Close
                  </Button>
                  <Button>
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Reverify
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Client</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select client" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="alex">Alex Johnson</SelectItem>
                        <SelectItem value="maya">Maya Patel</SelectItem>
                        <SelectItem value="ethan">Ethan Williams</SelectItem>
                        <SelectItem value="sophia">Sophia Garcia</SelectItem>
                        <SelectItem value="noah">Noah Chen</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Insurance Provider</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bcbs">Blue Cross Blue Shield</SelectItem>
                        <SelectItem value="aetna">Aetna</SelectItem>
                        <SelectItem value="uhc">UnitedHealthcare</SelectItem>
                        <SelectItem value="cigna">Cigna</SelectItem>
                        <SelectItem value="humana">Humana</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Policy Number</label>
                    <Input placeholder="Enter policy number" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Group Number</label>
                    <Input placeholder="Enter group number" />
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Policyholder Name</label>
                    <Input placeholder="Enter policyholder name" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Policyholder DOB</label>
                    <Input type="date" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Relationship to Client</label>
                    <Select defaultValue="parent">
                      <SelectTrigger>
                        <SelectValue placeholder="Select relationship" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="self">Self</SelectItem>
                        <SelectItem value="parent">Parent</SelectItem>
                        <SelectItem value="guardian">Legal Guardian</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Insurance Phone</label>
                    <Input placeholder="Enter insurance phone number" />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Services to Verify</label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="aba"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked
                    />
                    <label htmlFor="aba" className="text-sm">
                      ABA Therapy
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="speech"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked
                    />
                    <label htmlFor="speech" className="text-sm">
                      Speech Therapy
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="occupational"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked
                    />
                    <label htmlFor="occupational" className="text-sm">
                      Occupational Therapy
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            {!(selectedVerification?.status === "Verified" || selectedVerification?.status === "Expiring Soon") && (
              <>
                <Button variant="outline" onClick={() => setIsVerificationDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsVerificationDialogOpen(false)}>Submit Verification</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Authorization Dialog */}
      <Dialog open={isAuthDialogOpen} onOpenChange={setIsAuthDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Service Authorization</DialogTitle>
            <DialogDescription>Add or update service authorization details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Client</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="alex">Alex Johnson</SelectItem>
                  <SelectItem value="maya">Maya Patel</SelectItem>
                  <SelectItem value="ethan">Ethan Williams</SelectItem>
                  <SelectItem value="sophia">Sophia Garcia</SelectItem>
                  <SelectItem value="noah">Noah Chen</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Insurance Provider</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select provider" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bcbs">Blue Cross Blue Shield</SelectItem>
                  <SelectItem value="aetna">Aetna</SelectItem>
                  <SelectItem value="uhc">UnitedHealthcare</SelectItem>
                  <SelectItem value="cigna">Cigna</SelectItem>
                  <SelectItem value="humana">Humana</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Service Type</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select service type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aba">ABA Therapy</SelectItem>
                  <SelectItem value="speech">Speech Therapy</SelectItem>
                  <SelectItem value="occupational">Occupational Therapy</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Authorization Number</label>
              <Input placeholder="Enter authorization number" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Start Date</label>
                <Input type="date" />
              </div>
              <div>
                <label className="text-sm font-medium">End Date</label>
                <Input type="date" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Authorized Hours</label>
              <Input type="number" placeholder="Hours per month" />
            </div>
            <div>
              <label className="text-sm font-medium">Notes</label>
              <Textarea placeholder="Enter any additional notes or requirements" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAuthDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsAuthDialogOpen(false)}>Save Authorization</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

