"use client"

import { Calendar } from "@/components/ui/calendar"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  ChevronLeft,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  UserPlus,
  Phone,
  Mail,
  FileText,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock referral data
const REFERRALS = [
  {
    id: 1,
    client: "Noah Chen",
    age: 5,
    referralSource: "Dr. James Wilson",
    sourceType: "Pediatrician",
    date: new Date(2024, 2, 10),
    status: "New",
    services: ["ABA Therapy", "Speech Therapy"],
    contactInfo: {
      parent: "Wei Chen",
      phone: "(555) 123-4567",
      email: "wei.chen@example.com",
      address: "123 Maple St, Anytown, CA",
    },
    notes:
      "Noah shows signs of developmental delay and difficulty with social interactions. Pediatrician recommends evaluation for ASD and early intervention services.",
  },
  {
    id: 2,
    client: "Emma Rodriguez",
    age: 4,
    referralSource: "Sunshine Elementary School",
    sourceType: "School",
    date: new Date(2024, 2, 5),
    status: "In Progress",
    services: ["ABA Therapy"],
    contactInfo: {
      parent: "Maria Rodriguez",
      phone: "(555) 234-5678",
      email: "maria.rodriguez@example.com",
      address: "456 Oak Ave, Anytown, CA",
    },
    notes:
      "School psychologist observed behavioral challenges in classroom setting. Recommends evaluation for possible ABA therapy services.",
  },
  {
    id: 3,
    client: "Liam Johnson",
    age: 6,
    referralSource: "Dr. Sarah Miller",
    sourceType: "Neurologist",
    date: new Date(2024, 1, 20),
    status: "Scheduled",
    services: ["ABA Therapy", "Occupational Therapy"],
    contactInfo: {
      parent: "Michael Johnson",
      phone: "(555) 345-6789",
      email: "michael.johnson@example.com",
      address: "789 Pine Rd, Anytown, CA",
    },
    notes:
      "Recent ASD diagnosis. Parents seeking comprehensive therapy services. Initial evaluation scheduled for March 15.",
  },
  {
    id: 4,
    client: "Olivia Williams",
    age: 3,
    referralSource: "Early Intervention Program",
    sourceType: "Government Agency",
    date: new Date(2024, 1, 15),
    status: "Contacted",
    services: ["Speech Therapy", "ABA Therapy"],
    contactInfo: {
      parent: "Jennifer Williams",
      phone: "(555) 456-7890",
      email: "jennifer.williams@example.com",
      address: "101 Cedar Ln, Anytown, CA",
    },
    notes:
      "Speech delay identified through early screening. Parents contacted and interested in services. Awaiting insurance verification.",
  },
  {
    id: 5,
    client: "Ethan Davis",
    age: 7,
    referralSource: "Family Friend",
    sourceType: "Self-Referral",
    date: new Date(2024, 1, 5),
    status: "Enrolled",
    services: ["ABA Therapy"],
    contactInfo: {
      parent: "Robert Davis",
      phone: "(555) 567-8901",
      email: "robert.davis@example.com",
      address: "202 Birch Blvd, Anytown, CA",
    },
    notes:
      "Family seeking services after positive experience from friend. Initial assessment complete. Therapy scheduled to begin next week.",
  },
]

// Mock referral sources
const REFERRAL_SOURCES = [
  {
    id: 1,
    name: "Dr. James Wilson",
    type: "Pediatrician",
    organization: "Anytown Pediatrics",
    contactInfo: {
      phone: "(555) 987-6543",
      email: "jwilson@anytownpediatrics.com",
      address: "500 Medical Center Dr, Anytown, CA",
    },
    referralsCount: 12,
    active: true,
  },
  {
    id: 2,
    name: "Dr. Sarah Miller",
    type: "Neurologist",
    organization: "Anytown Neurology Center",
    contactInfo: {
      phone: "(555) 876-5432",
      email: "smiller@anytownneurology.com",
      address: "600 Medical Center Dr, Anytown, CA",
    },
    referralsCount: 8,
    active: true,
  },
  {
    id: 3,
    name: "Sunshine Elementary School",
    type: "School",
    organization: "Anytown School District",
    contactInfo: {
      phone: "(555) 765-4321",
      email: "counselor@sunshineschool.edu",
      address: "300 Education Blvd, Anytown, CA",
    },
    referralsCount: 15,
    active: true,
  },
  {
    id: 4,
    name: "Early Intervention Program",
    type: "Government Agency",
    organization: "Anytown Department of Health",
    contactInfo: {
      phone: "(555) 654-3210",
      email: "eip@anytownhealth.gov",
      address: "400 Government Way, Anytown, CA",
    },
    referralsCount: 20,
    active: true,
  },
  {
    id: 5,
    name: "Dr. Michael Brown",
    type: "Psychologist",
    organization: "Anytown Psychology Associates",
    contactInfo: {
      phone: "(555) 543-2109",
      email: "mbrown@anytownpsych.com",
      address: "700 Medical Center Dr, Anytown, CA",
    },
    referralsCount: 5,
    active: true,
  },
]

export default function ReferralsPage() {
  const [activeTab, setActiveTab] = useState("referrals")
  const [isNewReferralDialogOpen, setIsNewReferralDialogOpen] = useState(false)
  const [isNewSourceDialogOpen, setIsNewSourceDialogOpen] = useState(false)
  const [selectedReferral, setSelectedReferral] = useState<(typeof REFERRALS)[0] | null>(null)

  return (
    <div className="flex min-h-screen flex-col">      

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Referral Management</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search referrals..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button onClick={() => setIsNewReferralDialogOpen(true)}>
              <UserPlus className="mr-2 h-4 w-4" />
              New Referral
            </Button>
          </div>
        </div>

        <Tabs defaultValue="referrals" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="referrals">Referrals</TabsTrigger>
            <TabsTrigger value="sources">Referral Sources</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Referrals Tab */}
          <TabsContent value="referrals">
            <Card>
              <CardHeader>
                <CardTitle>Client Referrals</CardTitle>
                <CardDescription>Manage incoming client referrals and track their status</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client</TableHead>
                      <TableHead>Age</TableHead>
                      <TableHead>Referral Source</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Services</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {REFERRALS.map((referral) => (
                      <TableRow key={referral.id}>
                        <TableCell className="font-medium">{referral.client}</TableCell>
                        <TableCell>{referral.age}</TableCell>
                        <TableCell>
                          <div>
                            <p>{referral.referralSource}</p>
                            <p className="text-xs text-muted-foreground">{referral.sourceType}</p>
                          </div>
                        </TableCell>
                        <TableCell>{format(referral.date, "MMM d, yyyy")}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {referral.services.map((service, index) => (
                              <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                {service}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              referral.status === "New"
                                ? "default"
                                : referral.status === "Contacted"
                                  ? "secondary"
                                  : referral.status === "In Progress"
                                    ? "secondary"
                                    : referral.status === "Scheduled"
                                      ? "outline"
                                      : "outline"
                            }
                            className={
                              referral.status === "New"
                                ? "bg-blue-50 text-blue-700 border-blue-200"
                                : referral.status === "Contacted"
                                  ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                  : referral.status === "In Progress"
                                    ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                    : referral.status === "Scheduled"
                                      ? "bg-purple-50 text-purple-700 border-purple-200"
                                      : "bg-green-50 text-green-700 border-green-200"
                            }
                          >
                            <div className="flex items-center gap-1">
                              {referral.status === "New" && <AlertCircle className="h-3.5 w-3.5" />}
                              {referral.status === "Contacted" && <Phone className="h-3.5 w-3.5" />}
                              {referral.status === "In Progress" && <Clock className="h-3.5 w-3.5" />}
                              {referral.status === "Scheduled" && <Calendar className="h-3.5 w-3.5" />}
                              {referral.status === "Enrolled" && <CheckCircle2 className="h-3.5 w-3.5" />}
                              <span>{referral.status}</span>
                            </div>
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedReferral(referral)
                              setIsNewReferralDialogOpen(true)
                            }}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Referral Sources Tab */}
          <TabsContent value="sources">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Referral Sources</CardTitle>
                  <CardDescription>Manage and track your referral network</CardDescription>
                </div>
                <Button onClick={() => setIsNewSourceDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Source
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Organization</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Referrals</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {REFERRAL_SOURCES.map((source) => (
                      <TableRow key={source.id}>
                        <TableCell className="font-medium">{source.name}</TableCell>
                        <TableCell>{source.type}</TableCell>
                        <TableCell>{source.organization}</TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <div className="flex items-center gap-1">
                              <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="text-sm">{source.contactInfo.phone}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="text-sm">{source.contactInfo.email}</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{source.referralsCount}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              source.active
                                ? "bg-green-50 text-green-700 border-green-200"
                                : "bg-red-50 text-red-700 border-red-200"
                            }
                          >
                            {source.active ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              View
                            </Button>
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Referrals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">42</div>
                  <p className="text-xs text-muted-foreground">Last 90 days</p>
                  <div className="mt-2 flex items-center text-sm">
                    <span className="text-green-500 mr-1">↑ 12%</span>
                    <span className="text-muted-foreground">from previous period</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">68%</div>
                  <p className="text-xs text-muted-foreground">Referrals to clients</p>
                  <div className="mt-2 flex items-center text-sm">
                    <span className="text-green-500 mr-1">↑ 5%</span>
                    <span className="text-muted-foreground">from previous period</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Top Referral Source</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">Early Intervention Program</div>
                  <p className="text-xs text-muted-foreground">20 referrals</p>
                  <div className="mt-2 flex items-center text-sm">
                    <span className="text-muted-foreground">48% of total referrals</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Referral Analytics</CardTitle>
                <CardDescription>Track referral trends and conversion rates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <h3 className="text-lg font-medium mb-4">Referrals by Source Type</h3>
                    <div className="h-[300px] w-full bg-muted rounded-md flex items-center justify-center">
                      <p className="text-muted-foreground">Chart visualization would appear here</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-4">Referral Status Distribution</h3>
                    <div className="h-[300px] w-full bg-muted rounded-md flex items-center justify-center">
                      <p className="text-muted-foreground">Chart visualization would appear here</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-4">Monthly Referral Trends</h3>
                    <div className="h-[300px] w-full bg-muted rounded-md flex items-center justify-center">
                      <p className="text-muted-foreground">Chart visualization would appear here</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="ml-auto">
                  <FileText className="mr-2 h-4 w-4" />
                  Export Report
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* New Referral Dialog */}
      <Dialog open={isNewReferralDialogOpen} onOpenChange={setIsNewReferralDialogOpen}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>{selectedReferral ? `Referral: ${selectedReferral.client}` : "New Referral"}</DialogTitle>
            <DialogDescription>
              {selectedReferral ? "View or update referral details" : "Add a new client referral to the system"}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Client Name</label>
                <Input placeholder="Enter client name" defaultValue={selectedReferral?.client || ""} />
              </div>
              <div>
                <label className="text-sm font-medium">Age</label>
                <Input type="number" placeholder="Enter age" defaultValue={selectedReferral?.age || ""} />
              </div>
              <div>
                <label className="text-sm font-medium">Referral Source</label>
                <Select defaultValue={selectedReferral?.referralSource ? "existing" : "new"}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select referral source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">Add New Source</SelectItem>
                    <SelectItem value="existing">Select Existing Source</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Existing Source</label>
                <Select defaultValue={selectedReferral?.referralSource || ""}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select source" />
                  </SelectTrigger>
                  <SelectContent>
                    {REFERRAL_SOURCES.map((source) => (
                      <SelectItem key={source.id} value={source.name}>
                        {source.name} ({source.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Services Needed</label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="aba"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked={selectedReferral?.services.includes("ABA Therapy")}
                    />
                    <label htmlFor="aba" className="text-sm">
                      ABA Therapy
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="speech"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked={selectedReferral?.services.includes("Speech Therapy")}
                    />
                    <label htmlFor="speech" className="text-sm">
                      Speech Therapy
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="occupational"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked={selectedReferral?.services.includes("Occupational Therapy")}
                    />
                    <label htmlFor="occupational" className="text-sm">
                      Occupational Therapy
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="behavioral"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      defaultChecked={selectedReferral?.services.includes("Behavioral Therapy")}
                    />
                    <label htmlFor="behavioral" className="text-sm">
                      Behavioral Therapy
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Parent/Guardian Name</label>
                <Input
                  placeholder="Enter parent/guardian name"
                  defaultValue={selectedReferral?.contactInfo.parent || ""}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Phone</label>
                <Input placeholder="Enter phone number" defaultValue={selectedReferral?.contactInfo.phone || ""} />
              </div>
              <div>
                <label className="text-sm font-medium">Email</label>
                <Input
                  type="email"
                  placeholder="Enter email address"
                  defaultValue={selectedReferral?.contactInfo.email || ""}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Address</label>
                <Input placeholder="Enter address" defaultValue={selectedReferral?.contactInfo.address || ""} />
              </div>
              <div>
                <label className="text-sm font-medium">Status</label>
                <Select defaultValue={selectedReferral?.status || "New"}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="New">New</SelectItem>
                    <SelectItem value="Contacted">Contacted</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Scheduled">Scheduled</SelectItem>
                    <SelectItem value="Enrolled">Enrolled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium">Notes</label>
            <Textarea
              placeholder="Enter any additional notes or information"
              className="mt-1"
              rows={4}
              defaultValue={selectedReferral?.notes || ""}
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewReferralDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsNewReferralDialogOpen(false)}>
              {selectedReferral ? "Update Referral" : "Save Referral"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Source Dialog */}
      <Dialog open={isNewSourceDialogOpen} onOpenChange={setIsNewSourceDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Referral Source</DialogTitle>
            <DialogDescription>Add a new referral source to your network</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Name</label>
              <Input placeholder="Enter name" />
            </div>
            <div>
              <label className="text-sm font-medium">Type</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pediatrician">Pediatrician</SelectItem>
                  <SelectItem value="neurologist">Neurologist</SelectItem>
                  <SelectItem value="psychologist">Psychologist</SelectItem>
                  <SelectItem value="school">School</SelectItem>
                  <SelectItem value="agency">Government Agency</SelectItem>
                  <SelectItem value="self">Self-Referral</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Organization</label>
              <Input placeholder="Enter organization name" />
            </div>
            <div>
              <label className="text-sm font-medium">Phone</label>
              <Input placeholder="Enter phone number" />
            </div>
            <div>
              <label className="text-sm font-medium">Email</label>
              <Input type="email" placeholder="Enter email address" />
            </div>
            <div>
              <label className="text-sm font-medium">Address</label>
              <Input placeholder="Enter address" />
            </div>
            <div>
              <label className="text-sm font-medium">Notes</label>
              <Textarea placeholder="Enter any additional notes" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewSourceDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsNewSourceDialogOpen(false)}>Add Source</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

