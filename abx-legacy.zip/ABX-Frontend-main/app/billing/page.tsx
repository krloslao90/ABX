"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  ChevronLeft,
  Search,
  Filter,
  Download,
  Printer,
  CreditCard,
  Plus,
  FileText,
  Mail,
  ArrowUpRight,
  AlertCircle,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock invoice data
const INVOICES = [
  {
    id: "INV-2024-0315",
    client: "Alex Johnson",
    date: new Date(2024, 2, 15),
    dueDate: new Date(2024, 2, 30),
    amount: 750.0,
    status: "Pending",
    items: [{ description: "Speech Therapy (5 sessions)", rate: 150.0, quantity: 5, total: 750.0 }],
  },
  {
    id: "INV-2024-0310",
    client: "Maya Patel",
    date: new Date(2024, 2, 10),
    dueDate: new Date(2024, 2, 25),
    amount: 675.0,
    status: "Paid",
    items: [
      { description: "Behavioral Therapy (3 sessions)", rate: 150.0, quantity: 3, total: 450.0 },
      { description: "Parent Training (1 session)", rate: 225.0, quantity: 1, total: 225.0 },
    ],
  },
  {
    id: "INV-2024-0305",
    client: "Ethan Williams",
    date: new Date(2024, 2, 5),
    dueDate: new Date(2024, 2, 20),
    amount: 600.0,
    status: "Overdue",
    items: [{ description: "Occupational Therapy (4 sessions)", rate: 150.0, quantity: 4, total: 600.0 }],
  },
  {
    id: "INV-2024-0301",
    client: "Sophia Garcia",
    date: new Date(2024, 2, 1),
    dueDate: new Date(2024, 2, 16),
    amount: 900.0,
    status: "Paid",
    items: [
      { description: "Behavioral Therapy (4 sessions)", rate: 150.0, quantity: 4, total: 600.0 },
      { description: "Group Social Skills (2 sessions)", rate: 150.0, quantity: 2, total: 300.0 },
    ],
  },
  {
    id: "INV-2024-0225",
    client: "Noah Chen",
    date: new Date(2024, 1, 25),
    dueDate: new Date(2024, 2, 10),
    amount: 1125.0,
    status: "Paid",
    items: [
      { description: "Initial Assessment", rate: 375.0, quantity: 1, total: 375.0 },
      { description: "Speech Therapy (5 sessions)", rate: 150.0, quantity: 5, total: 750.0 },
    ],
  },
  {
    id: "INV-2024-0220",
    client: "Alex Johnson",
    date: new Date(2024, 1, 20),
    dueDate: new Date(2024, 2, 5),
    amount: 600.0,
    status: "Paid",
    items: [{ description: "Speech Therapy (4 sessions)", rate: 150.0, quantity: 4, total: 600.0 }],
  },
  {
    id: "INV-2024-0215",
    client: "Maya Patel",
    date: new Date(2024, 1, 15),
    dueDate: new Date(2024, 2, 1),
    amount: 750.0,
    status: "Paid",
    items: [{ description: "Behavioral Therapy (5 sessions)", rate: 150.0, quantity: 5, total: 750.0 }],
  },
  {
    id: "INV-2024-0210",
    client: "Ethan Williams",
    date: new Date(2024, 1, 10),
    dueDate: new Date(2024, 1, 25),
    amount: 450.0,
    status: "Paid",
    items: [{ description: "Occupational Therapy (3 sessions)", rate: 150.0, quantity: 3, total: 450.0 }],
  },
]

// Mock payment data
const PAYMENTS = [
  {
    id: "PMT-2024-0310",
    client: "Maya Patel",
    date: new Date(2024, 2, 10),
    amount: 675.0,
    method: "Credit Card",
    invoice: "INV-2024-0310",
  },
  {
    id: "PMT-2024-0301",
    client: "Sophia Garcia",
    date: new Date(2024, 2, 1),
    amount: 900.0,
    method: "Insurance",
    invoice: "INV-2024-0301",
  },
  {
    id: "PMT-2024-0228",
    client: "Noah Chen",
    date: new Date(2024, 1, 28),
    amount: 1125.0,
    method: "Bank Transfer",
    invoice: "INV-2024-0225",
  },
  {
    id: "PMT-2024-0225",
    client: "Alex Johnson",
    date: new Date(2024, 1, 25),
    amount: 600.0,
    method: "Credit Card",
    invoice: "INV-2024-0220",
  },
  {
    id: "PMT-2024-0220",
    client: "Maya Patel",
    date: new Date(2024, 1, 20),
    amount: 750.0,
    method: "Insurance",
    invoice: "INV-2024-0215",
  },
  {
    id: "PMT-2024-0215",
    client: "Ethan Williams",
    date: new Date(2024, 1, 15),
    amount: 450.0,
    method: "Credit Card",
    invoice: "INV-2024-0210",
  },
]

export default function BillingPage() {
  const [selectedInvoice, setSelectedInvoice] = useState(INVOICES[0])
  const [isViewInvoiceOpen, setIsViewInvoiceOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("invoices")

  return (
    <div className="flex min-h-screen flex-col">

      {/* Main Content */}
      <main className="flex-1 container py-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="icon" asChild className="mr-2">
            <Link href="/">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Back</span>
            </Link>
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Billing & Invoicing</h2>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input type="search" placeholder="Search invoices..." className="w-[250px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Invoice
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Invoiced</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$5,850.00</div>
              <p className="text-xs text-muted-foreground">Current month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Payments Received</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$4,500.00</div>
              <p className="text-xs text-muted-foreground">Current month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Outstanding Balance</CardTitle>
              <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$1,350.00</div>
              <p className="text-xs text-muted-foreground">Across all clients</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Overdue Invoices</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1</div>
              <p className="text-xs text-muted-foreground">Requires attention</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="invoices" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="invoices">Invoices</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="insurance">Insurance Claims</TabsTrigger>
          </TabsList>

          {/* Invoices Tab */}
          <TabsContent value="invoices">
            <Card>
              <CardHeader>
                <CardTitle>Invoices</CardTitle>
                <CardDescription>Manage and track all client invoices</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {INVOICES.map((invoice) => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">{invoice.id}</TableCell>
                        <TableCell>{invoice.client}</TableCell>
                        <TableCell>{format(invoice.date, "MMM d, yyyy")}</TableCell>
                        <TableCell>{format(invoice.dueDate, "MMM d, yyyy")}</TableCell>
                        <TableCell>${invoice.amount.toFixed(2)}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              invoice.status === "Paid"
                                ? "outline"
                                : invoice.status === "Pending"
                                  ? "secondary"
                                  : "destructive"
                            }
                            className={
                              invoice.status === "Paid"
                                ? "bg-green-50 text-green-700 border-green-200"
                                : invoice.status === "Pending"
                                  ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                                  : ""
                            }
                          >
                            {invoice.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedInvoice(invoice)
                              setIsViewInvoiceOpen(true)
                            }}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle>Payments</CardTitle>
                <CardDescription>Track all payment transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Payment ID</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Invoice</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {PAYMENTS.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium">{payment.id}</TableCell>
                        <TableCell>{payment.client}</TableCell>
                        <TableCell>{format(payment.date, "MMM d, yyyy")}</TableCell>
                        <TableCell>${payment.amount.toFixed(2)}</TableCell>
                        <TableCell>{payment.method}</TableCell>
                        <TableCell>{payment.invoice}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Receipt
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Insurance Claims Tab */}
          <TabsContent value="insurance">
            <Card>
              <CardHeader>
                <CardTitle>Insurance Claims</CardTitle>
                <CardDescription>Manage and track insurance claims</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <FileText className="h-10 w-10 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No Active Claims</h3>
                  <p className="text-sm text-muted-foreground mt-2 mb-4">
                    There are no active insurance claims at the moment.
                  </p>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Submit New Claim
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* View Invoice Dialog */}
        <Dialog open={isViewInvoiceOpen} onOpenChange={setIsViewInvoiceOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Invoice {selectedInvoice.id}</DialogTitle>
              <DialogDescription>
                {selectedInvoice.client} • {format(selectedInvoice.date, "MMMM d, yyyy")}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div className="flex justify-between">
                <div>
                  <h3 className="font-medium">ABX Therapy Center</h3>
                  <p className="text-sm text-muted-foreground">123 Therapy Lane</p>
                  <p className="text-sm text-muted-foreground">Anytown, CA 94123</p>
                  <p className="text-sm text-muted-foreground">info@abxtherapy.com</p>
                </div>
                <div className="text-right">
                  <h3 className="font-medium">Bill To:</h3>
                  <p className="text-sm">{selectedInvoice.client}</p>
                  <p className="text-sm text-muted-foreground">Parent: Sarah Johnson</p>
                  <p className="text-sm text-muted-foreground">123 Main Street</p>
                  <p className="text-sm text-muted-foreground">Anytown, CA 94123</p>
                </div>
              </div>

              <div className="flex justify-between">
                <div>
                  <p className="text-sm font-medium">Invoice Date:</p>
                  <p className="text-sm">{format(selectedInvoice.date, "MMMM d, yyyy")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Due Date:</p>
                  <p className="text-sm">{format(selectedInvoice.dueDate, "MMMM d, yyyy")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Status:</p>
                  <Badge
                    variant={
                      selectedInvoice.status === "Paid"
                        ? "outline"
                        : selectedInvoice.status === "Pending"
                          ? "secondary"
                          : "destructive"
                    }
                    className={
                      selectedInvoice.status === "Paid"
                        ? "bg-green-50 text-green-700 border-green-200"
                        : selectedInvoice.status === "Pending"
                          ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                          : ""
                    }
                  >
                    {selectedInvoice.status}
                  </Badge>
                </div>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Rate</TableHead>
                    <TableHead className="text-right">Quantity</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedInvoice.items.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{item.description}</TableCell>
                      <TableCell className="text-right">${item.rate.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{item.quantity}</TableCell>
                      <TableCell className="text-right">${item.total.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="flex justify-end">
                <div className="w-[200px]">
                  <div className="flex justify-between py-1">
                    <span className="font-medium">Subtotal:</span>
                    <span>${selectedInvoice.amount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="font-medium">Insurance Coverage:</span>
                    <span>$0.00</span>
                  </div>
                  <div className="flex justify-between py-1 border-t border-t-border mt-1 pt-2">
                    <span className="font-bold">Total Due:</span>
                    <span className="font-bold">${selectedInvoice.amount.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="text-sm text-muted-foreground">
                <p className="font-medium">Payment Terms:</p>
                <p>
                  Payment is due within 15 days of invoice date. Please make checks payable to ABX Therapy Center or pay
                  online.
                </p>
              </div>
            </div>
            <DialogFooter className="flex justify-between items-center">
              <div>
                {selectedInvoice.status === "Pending" || selectedInvoice.status === "Overdue" ? (
                  <Button variant="default">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Pay Now
                  </Button>
                ) : null}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsViewInvoiceOpen(false)}>
                  Close
                </Button>
                <Button variant="outline">
                  <Printer className="mr-2 h-4 w-4" />
                  Print
                </Button>
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
                <Button variant="outline">
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}

