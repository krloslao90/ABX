import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CalendarDays, Users, Clock, BarChart3 } from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Main Content */}
      <main className="flex-1 container p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <div className="flex items-center gap-2">
            <Button>
              <Users className="mr-2 h-4 w-4" />
              Add Client
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">42</div>
              <p className="text-xs text-muted-foreground">+2 this month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Sessions Today</CardTitle>
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">3 remaining</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Therapy Hours</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">86.5</div>
              <p className="text-xs text-muted-foreground">This week</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Goal Progress</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">68%</div>
              <p className="text-xs text-muted-foreground">Across all clients</p>
            </CardContent>
          </Card>
        </div>

        {/* Client List and Upcoming Sessions */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Client List */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Recent Clients</CardTitle>
              <CardDescription>Your most recently updated client profiles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "Alex Johnson", age: 6, status: "Active", lastSession: "Today" },
                  { name: "Maya Patel", age: 8, status: "Active", lastSession: "Yesterday" },
                  { name: "Ethan Williams", age: 5, status: "On Hold", lastSession: "3 days ago" },
                  { name: "Sophia Garcia", age: 7, status: "Active", lastSession: "1 week ago" },
                  { name: "Noah Chen", age: 4, status: "New", lastSession: "Not started" },
                ].map((client, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>
                          {client.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{client.name}</p>
                        <p className="text-sm text-muted-foreground">Age: {client.age}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={
                          client.status === "Active" ? "default" : client.status === "On Hold" ? "secondary" : "outline"
                        }
                      >
                        {client.status}
                      </Badge>
                      <p className="text-xs text-muted-foreground whitespace-nowrap">{client.lastSession}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Button variant="outline" asChild>
                  <Link href="/clients">View All Clients</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Sessions */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Today's Sessions</CardTitle>
              <CardDescription>Upcoming therapy sessions for today</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { time: "9:00 AM", client: "Alex Johnson", therapist: "Dr. Sarah Miller", type: "Speech" },
                  { time: "10:30 AM", client: "Maya Patel", therapist: "Thomas Wilson", type: "Behavioral" },
                  { time: "1:00 PM", client: "Noah Chen", therapist: "Dr. Sarah Miller", type: "Initial Assessment" },
                  { time: "2:30 PM", client: "Ethan Williams", therapist: "Jessica Taylor", type: "Occupational" },
                  { time: "4:00 PM", client: "Sophia Garcia", therapist: "Thomas Wilson", type: "Behavioral" },
                ].map((session, i) => (
                  <div key={i} className="flex items-center gap-4 p-2 rounded-lg hover:bg-muted">
                    <div className="flex h-12 w-12 items-center justify-center rounded-md border bg-muted">
                      <span className="text-sm font-medium">{session.time}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{session.client}</p>
                      <p className="text-sm text-muted-foreground">
                        {session.therapist} • {session.type}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">
                      Details
                    </Button>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Button variant="outline" asChild>
                  <Link href="/schedule">Full Schedule</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

