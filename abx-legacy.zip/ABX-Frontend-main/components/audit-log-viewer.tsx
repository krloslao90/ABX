"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Download, Search, Filter, Calendar } from "lucide-react"
import { format } from "date-fns"

// Mock audit log data
const AUDIT_LOGS = [
  {
    id: 1,
    timestamp: new Date(2024, 2, 15, 9, 30),
    user: "admin@abxtherapy.com",
    action: "VIEW",
    resource: "Client Profile",
    resourceId: "client_1",
    details: "Viewed client profile for Alex Johnson",
    ipAddress: "192.168.1.1",
  },
  {
    id: 2,
    timestamp: new Date(2024, 2, 15, 10, 15),
    user: "sarah.miller@abxtherapy.com",
    action: "UPDATE",
    resource: "Session Notes",
    resourceId: "session_5",
    details: "Updated session notes for Alex Johnson",
    ipAddress: "192.168.1.2",
  },
  {
    id: 3,
    timestamp: new Date(2024, 2, 15, 11, 0),
    user: "thomas.wilson@abxtherapy.com",
    action: "CREATE",
    resource: "Treatment Plan",
    resourceId: "plan_3",
    details: "Created new treatment plan for Maya Patel",
    ipAddress: "192.168.1.3",
  },
  {
    id: 4,
    timestamp: new Date(2024, 2, 15, 13, 45),
    user: "admin@abxtherapy.com",
    action: "EXPORT",
    resource: "Client Data",
    resourceId: "client_2",
    details: "Exported client data for Maya Patel",
    ipAddress: "192.168.1.1",
  },
  {
    id: 5,
    timestamp: new Date(2024, 2, 15, 14, 30),
    user: "jessica.taylor@abxtherapy.com",
    action: "VIEW",
    resource: "Billing Records",
    resourceId: "invoice_10",
    details: "Viewed billing records for Ethan Williams",
    ipAddress: "192.168.1.4",
  },
  {
    id: 6,
    timestamp: new Date(2024, 2, 15, 15, 0),
    user: "admin@abxtherapy.com",
    action: "UPDATE",
    resource: "User Permissions",
    resourceId: "user_5",
    details: "Updated permissions for Jessica Taylor",
    ipAddress: "192.168.1.1",
  },
  {
    id: 7,
    timestamp: new Date(2024, 2, 15, 16, 15),
    user: "sarah.miller@abxtherapy.com",
    action: "DELETE",
    resource: "Appointment",
    resourceId: "appointment_8",
    details: "Cancelled appointment for Noah Chen",
    ipAddress: "192.168.1.2",
  },
]

export function AuditLogViewer() {
  const [dateRange, setDateRange] = useState("today")
  const [actionFilter, setActionFilter] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  // Filter logs based on selected filters
  const filteredLogs = AUDIT_LOGS.filter((log) => {
    // Filter by action type
    if (actionFilter !== "all" && log.action !== actionFilter) {
      return false
    }

    // Filter by search query
    if (
      searchQuery &&
      !log.details.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !log.user.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    return true
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle>Audit Logs</CardTitle>
        <CardDescription>Track all system activities for compliance and security</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[180px]">
                <Calendar className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Select date range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="yesterday">Yesterday</SelectItem>
                <SelectItem value="week">Last 7 days</SelectItem>
                <SelectItem value="month">Last 30 days</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Filter by action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="VIEW">View</SelectItem>
                <SelectItem value="CREATE">Create</SelectItem>
                <SelectItem value="UPDATE">Update</SelectItem>
                <SelectItem value="DELETE">Delete</SelectItem>
                <SelectItem value="EXPORT">Export</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search logs..."
                className="w-[250px] pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Logs
            </Button>
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Timestamp</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Resource</TableHead>
              <TableHead>Details</TableHead>
              <TableHead>IP Address</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLogs.map((log) => (
              <TableRow key={log.id}>
                <TableCell>{format(log.timestamp, "MMM d, yyyy HH:mm:ss")}</TableCell>
                <TableCell>{log.user}</TableCell>
                <TableCell>
                  <span
                    className={
                      log.action === "VIEW"
                        ? "text-blue-600"
                        : log.action === "CREATE"
                          ? "text-green-600"
                          : log.action === "UPDATE"
                            ? "text-amber-600"
                            : log.action === "DELETE"
                              ? "text-red-600"
                              : log.action === "EXPORT"
                                ? "text-purple-600"
                                : ""
                    }
                  >
                    {log.action}
                  </span>
                </TableCell>
                <TableCell>{log.resource}</TableCell>
                <TableCell className="max-w-md truncate">{log.details}</TableCell>
                <TableCell>{log.ipAddress}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

