import type React from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

interface PageHeaderProps {
  title: string
  description?: string
  children?: React.ReactNode
}

export function PageHeader({ title, description, children }: PageHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
        {description && <p className="text-muted-foreground mt-1">{description}</p>}
      </div>
      <div className="flex items-center gap-2 w-full sm:w-auto">{children}</div>
    </div>
  )
}

export function SearchBar({ placeholder = "Search..." }: { placeholder?: string }) {
  return (
    <div className="relative w-full sm:w-auto">
      <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
      <Input type="search" placeholder={placeholder} className="w-full sm:w-[250px] pl-8" />
    </div>
  )
}

