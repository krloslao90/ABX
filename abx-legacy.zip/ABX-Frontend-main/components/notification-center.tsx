"use client"

import { useState } from "react"
import { Bell, Check, X, Info, Calendar, FileText, Clock, DollarSign, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { format, isToday, isYesterday } from "date-fns"

// Mock notification data
const NOTIFICATIONS = [
  {
    id: 1,
    type: "appointment",
    title: "Upcoming Session",
    message: "Session with Alex Johnson tomorrow at 10:00 AM",
    date: new Date(new Date().getTime() + 24 * 60 * 60 * 1000),
    read: false,
    priority: "medium",
  },
  {
    id: 2,
    type: "document",
    title: "Document Needs Review",
    message: "Treatment plan for Maya Patel requires your review",
    date: new Date(new Date().getTime() - 2 * 60 * 60 * 1000),
    read: false,
    priority: "high",
  },
  {
    id: 3,
    type: "authorization",
    title: "Authorization Expiring",
    message: "Service authorization for Ethan Williams expires in 7 days",
    date: new Date(new Date().getTime() - 12 * 60 * 60 * 1000),
    read: true,
    priority: "high",
  },
  {
    id: 4,
    type: "billing",
    title: "Payment Received",
    message: "Payment of $150.00 received from insurance for Alex Johnson",
    date: new Date(new Date().getTime() - 25 * 60 * 60 * 1000),
    read: true,
    priority: "low",
  },
  {
    id: 5,
    type: "message",
    title: "New Message",
    message: "New message from Sophia Garcia's parent regarding schedule",
    date: new Date(new Date().getTime() - 30 * 60 * 1000),
    read: false,
    priority: "medium",
  },
]

type NotificationType = "appointment" | "document" | "authorization" | "billing" | "message" | "system"

interface Notification {
  id: number
  type: NotificationType
  title: string
  message: string
  date: Date
  read: boolean
  priority: "low" | "medium" | "high"
}

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>(NOTIFICATIONS)
  const [open, setOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("all")

  const unreadCount = notifications.filter((n) => !n.read).length

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case "appointment":
        return <Calendar className="h-4 w-4" />
      case "document":
        return <FileText className="h-4 w-4" />
      case "authorization":
        return <Clock className="h-4 w-4" />
      case "billing":
        return <DollarSign className="h-4 w-4" />
      case "message":
        return <MessageSquare className="h-4 w-4" />
      default:
        return <Info className="h-4 w-4" />
    }
  }

  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-50 text-red-700 border-red-200"
      case "medium":
        return "bg-yellow-50 text-yellow-700 border-yellow-200"
      case "low":
        return "bg-green-50 text-green-700 border-green-200"
      default:
        return "bg-blue-50 text-blue-700 border-blue-200"
    }
  }

  const formatNotificationDate = (date: Date) => {
    if (isToday(date)) {
      return `Today at ${format(date, "h:mm a")}`
    } else if (isYesterday(date)) {
      return `Yesterday at ${format(date, "h:mm a")}`
    } else {
      return format(date, "MMM d, yyyy")
    }
  }

  const markAsRead = (id: number) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const dismissNotification = (id: number) => {
    setNotifications(notifications.filter((n) => n.id !== id))
  }

  const filteredNotifications =
    activeTab === "all"
      ? notifications
      : activeTab === "unread"
        ? notifications.filter((n) => !n.read)
        : notifications.filter((n) => n.priority === activeTab)

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-medium text-white">
              {unreadCount}
            </span>
          )}
          <span className="sr-only">Notifications</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0" align="end">
        <div className="flex items-center justify-between border-b px-4 py-2">
          <h4 className="font-semibold">Notifications</h4>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead}>
              <Check className="mr-2 h-3.5 w-3.5" />
              Mark all as read
            </Button>
          )}
        </div>
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <div className="border-b">
            <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
              <TabsTrigger
                value="all"
                className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              >
                All
              </TabsTrigger>
              <TabsTrigger
                value="unread"
                className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              >
                Unread
              </TabsTrigger>
              <TabsTrigger
                value="high"
                className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              >
                Important
              </TabsTrigger>
            </TabsList>
          </div>
          <TabsContent value={activeTab} className="max-h-[300px] overflow-auto">
            {filteredNotifications.length > 0 ? (
              <div className="space-y-1">
                {filteredNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={cn(
                      "flex items-start gap-3 px-4 py-3 transition-colors hover:bg-muted/50",
                      !notification.read && "bg-muted/50",
                    )}
                  >
                    <div
                      className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                        notification.priority === "high"
                          ? "bg-red-100"
                          : notification.priority === "medium"
                            ? "bg-yellow-100"
                            : "bg-blue-100",
                      )}
                    >
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <h5 className="font-medium">{notification.title}</h5>
                        <div className="flex items-center gap-2">
                          {!notification.read && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => markAsRead(notification.id)}
                            >
                              <Check className="h-3.5 w-3.5" />
                              <span className="sr-only">Mark as read</span>
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => dismissNotification(notification.id)}
                          >
                            <X className="h-3.5 w-3.5" />
                            <span className="sr-only">Dismiss</span>
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{notification.message}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {formatNotificationDate(notification.date)}
                        </span>
                        <Badge variant="outline" className={getPriorityStyles(notification.priority)}>
                          {notification.priority}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <Bell className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-semibold">No notifications</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  You're all caught up! No {activeTab === "all" ? "" : activeTab} notifications to display.
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
        <div className="flex items-center justify-between border-t p-4">
          <Button variant="outline" size="sm" asChild>
            <a href="/settings/notifications">Notification Settings</a>
          </Button>
          <Button variant="outline" size="sm" onClick={() => setOpen(false)}>
            Close
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}

