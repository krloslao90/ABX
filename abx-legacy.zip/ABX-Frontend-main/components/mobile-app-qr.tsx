import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Smartphone, Download, QrCode } from "lucide-react"

export function MobileAppQR() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="h-5 w-5" />
          ABX Mobile App
        </CardTitle>
        <CardDescription>Access ABX CRM on the go with our mobile app</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="parent">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="parent">Parent App</TabsTrigger>
            <TabsTrigger value="therapist">Therapist App</TabsTrigger>
          </TabsList>
          <TabsContent value="parent" className="pt-4">
            <div className="flex flex-col items-center text-center">
              <div className="bg-white p-4 rounded-lg mb-4">
                <QrCode className="h-32 w-32" />
              </div>
              <p className="text-sm mb-4">
                Scan this QR code to download the ABX Parent Portal app. Stay connected with your child's therapy
                progress, view session notes, and communicate with therapists.
              </p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  App Store
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Google Play
                </Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="therapist" className="pt-4">
            <div className="flex flex-col items-center text-center">
              <div className="bg-white p-4 rounded-lg mb-4">
                <QrCode className="h-32 w-32" />
              </div>
              <p className="text-sm mb-4">
                Scan this QR code to download the ABX Therapist app. Access client information, record session notes,
                and manage your schedule on the go.
              </p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  App Store
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Google Play
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

