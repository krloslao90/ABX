import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

// Mock data for goal progress
const GOAL_PROGRESS = [
  {
    id: 1,
    client: "Alex Johnson",
    goal: "Increase verbal requests for preferred items",
    progress: 65,
  },
  {
    id: 2,
    client: "Maya Patel",
    goal: "Reduce instances of tantrum behavior during transitions",
    progress: 80,
  },
  {
    id: 3,
    client: "Ethan Williams",
    goal: "Improve fine motor coordination",
    progress: 45,
  },
]

export function GoalProgressWidget() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Goal Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {GOAL_PROGRESS.map((goal) => (
            <div key={goal.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{goal.client}</p>
                <span className="text-sm text-muted-foreground">{goal.progress}%</span>
              </div>
              <p className="text-xs text-muted-foreground">{goal.goal}</p>
              <Progress value={goal.progress} className="h-2" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

