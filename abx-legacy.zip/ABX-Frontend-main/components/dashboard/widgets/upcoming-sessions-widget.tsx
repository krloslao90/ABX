import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Mock data for upcoming sessions
const UPCOMING_SESSIONS = [
  {
    id: 1,
    client: "Alex Johnson",
    therapist: "Dr. Sarah Miller",
    date: new Date(2024, 2, 15, 9, 0),
    type: "Speech",
  },
  {
    id: 2,
    client: "Maya Patel",
    therapist: "Thomas Wilson",
    date: new Date(2024, 2, 15, 11, 0),
    type: "Behavioral",
  },
  {
    id: 3,
    client: "Ethan Williams",
    therapist: "Jessica Taylor",
    date: new Date(2024, 2, 16, 14, 0),
    type: "Occupational",
  },
]

export function UpcomingSessionsWidget() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Upcoming Sessions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {UPCOMING_SESSIONS.map((session) => (
            <div key={session.id} className="flex items-center gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-md border bg-muted">
                <Calendar className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium">{session.client}</p>
                <p className="text-xs text-muted-foreground">
                  {format(session.date, "MMM d, h:mm a")} • {session.therapist}
                </p>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link href={`/calendar?date=${format(session.date, "yyyy-MM-dd")}`}>Details</Link>
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

